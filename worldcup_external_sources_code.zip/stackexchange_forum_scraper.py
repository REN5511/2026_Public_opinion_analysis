#!/usr/bin/env python3
import argparse,datetime,json,time
from pathlib import Path
import requests
ALIASES={'佛得角':['Cape Verde','Cabo Verde'],'沃齐尼亚':['Vozinha'],'世界杯':['World Cup'],'2026世界杯':['2026 World Cup'],'美加墨世界杯':['World Cup 2026'],'FIFA世界杯':['FIFA World Cup'],'西班牙':['Spain','Spanish'],'乌拉圭':['Uruguay'],'沙特':['Saudi','Saudi Arabia'],'阿根廷':['Argentina','Argentine'],'小组赛':['group stage'],'32强':['round of 32'],'淘汰赛':['knockout stage'],'晋级':['qualif','advance'],'出线':['qualif','advance'],'淘汰':['eliminat'],'加时':['extra time'],'首战':['opening match'],'首秀':['debut'],'首次参赛':['first appearance'],'首次世界杯':['first World Cup']}
EX={'篮球世界杯':['Basketball World Cup'],'男篮世界杯':["Men's Basketball World Cup"],'女篮世界杯':["Women's Basketball World Cup"],'电竞世界杯':['Esports World Cup'],'王者世界杯':['Honor of Kings World Cup'],'女足世界杯':["Women's World Cup"],'U17世界杯':['U17 World Cup'],'U20世界杯':['U20 World Cup'],'世俱杯':['Club World Cup'],'俱乐部世界杯':['Club World Cup']}
def exp(xs,m):return list(dict.fromkeys(y for x in xs for y in [x,*m.get(x,[])]))
def hit(s,ws):return [w for w in ws if w.casefold() in (s or '').casefold().replace('’',"'")]
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8'));out=Path(a.output);stp=out.with_suffix('.state.json');st=json.loads(stp.read_text(encoding='utf8')) if stp.exists() and not a.restart else {'page':1,'rows':[],'ids':[]};subs=exp(c['subject_keywords'],ALIASES);ev=exp(c['event_keywords'],ALIASES);ex=exp(c['exclude_keywords'],EX);ses=requests.Session();ses.headers['User-Agent']='football-research-stackexchange/1.0';
 if a.proxy:ses.proxies.update({'http':a.proxy,'https':a.proxy})
 while len(st['rows'])<a.limit and st['page']<=a.pages:
  try:r=ses.get('https://api.stackexchange.com/2.3/search/advanced',params={'site':'sports','q':'World Cup','page':st['page'],'pagesize':100,'filter':'withbody','fromdate':int(datetime.datetime.fromisoformat(c['start_date']).timestamp()),'todate':int((datetime.datetime.fromisoformat(c['end_date'])+datetime.timedelta(days=1)).timestamp())},timeout=45);r.raise_for_status();data=r.json()
  except Exception as e:print('request error',e);break
  for x in data.get('items',[]):
   text=(x.get('title','')+' '+x.get('body',''));hs=hit(text,subs);he=hit(text,ev);bad=hit(text,ex);u=x.get('link','')
   if hs and he and not bad and u and x['question_id'] not in st['ids']:
    st['ids'].append(x['question_id']);st['rows'].append({'record_type':'forum_post','source':'Sports Stack Exchange','forum':'Stack Exchange Sports','url':u,'title':x.get('title'),'published_at':datetime.datetime.fromtimestamp(x['creation_date'],datetime.timezone.utc).isoformat(),'bodyText':x.get('body',''),'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[]})
  st['page']+=1;stp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8');time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'][:a.limit])+'\n',encoding='utf8');print(json.dumps({'saved':len(st['rows']),'pages':st['page']},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/stackexchange_forum_strict.jsonl');p.add_argument('--limit',type=int,default=10000);p.add_argument('--pages',type=int,default=20);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=1);p.add_argument('--restart',action='store_true');run(p.parse_args())
