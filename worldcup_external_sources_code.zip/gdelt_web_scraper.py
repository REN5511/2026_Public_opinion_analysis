#!/usr/bin/env python3
import argparse,csv,json,time
from pathlib import Path
from urllib.parse import urlencode
import requests

ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup"],"2026世界杯":["2026 World Cup"],"美加墨世界杯":["World Cup 2026"],"FIFA世界杯":["FIFA World Cup"],"西班牙":["Spain","Spanish"],"乌拉圭":["Uruguay"],"沙特":["Saudi","Saudi Arabia"],"阿根廷":["Argentina","Argentine"],"小组赛":["group stage"],"32强":["round of 32"],"淘汰赛":["knockout stage"],"晋级":["qualif","advance"],"出线":["qualif","advance"],"淘汰":["eliminat"],"加时":["extra time"],"首战":["opening match"],"首秀":["debut"],"首次参赛":["first appearance"],"首次世界杯":["first World Cup"]}
EX=["basketball world cup","men's basketball world cup","women's basketball world cup","esports world cup","king's world cup","women's world cup","u17 world cup","u20 world cup","club world cup","club world cup"]
API='https://api.gdeltproject.org/api/v2/doc/doc'
def expand(xs): return list(dict.fromkeys(y for x in xs for y in [x,*ALIASES.get(x,[])]))
def hit(s,ws):
 l=(s or '').casefold(); return [w for w in ws if w.casefold() in l]
def main(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8')); subs=expand(c['subject_keywords']); ev=expand(c['event_keywords']); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); stp=out.with_suffix('.state.json'); st=json.loads(stp.read_text(encoding='utf8')) if stp.exists() and not a.restart else {'combo':0,'offset':0,'rows':[],'urls':[]}
 combos=[(s,e) for s in subs for e in ev]; ses=requests.Session(); ses.headers['User-Agent']='Mozilla/5.0 gdelt-research/1.0'
 while len(st['rows'])<a.limit and st['combo']<len(combos):
  s,e=combos[st['combo']]; q=f'"{s}" "{e}"'; p={'query':q,'mode':'artlist','maxrecords':250,'format':'json','sort':'datedesc','startdatetime':c['start_date'].replace('-','')+'000000','enddatetime':c['end_date'].replace('-','')+'235959'}
  try:
   r=ses.get(API,params=p,timeout=60)
   if r.status_code==429: time.sleep(a.sleep*10); continue
   r.raise_for_status(); data=r.json()
  except Exception as ex: print('request error',ex); time.sleep(a.sleep*5); continue
  arts=data.get('articles',[])
  for x in arts:
   txt=' '.join(str(x.get(k,'')) for k in ('title','seendate','socialimage','domain','language'))
   url=x.get('url',''); hs=hit(txt,subs); he=hit(txt,ev); bad=hit(txt,EX)
   if hs and he and not bad and url and url not in st['urls']:
    st['urls'].append(url); st['rows'].append({'url':url,'title':x.get('title'),'seendate':x.get('seendate'),'domain':x.get('domain'),'language':x.get('language'),'sourcecountry':x.get('sourcecountry'),'matched_subject_keywords':hs,'matched_event_keywords':he})
    if len(st['rows'])>=a.limit: break
  st['combo']+=1; stp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); time.sleep(a.sleep)
 rows=st['rows'][:a.limit]
 if out.suffix.lower()=='.csv':
  with out.open('w',newline='',encoding='utf-8-sig') as f: w=csv.DictWriter(f,fieldnames=rows[0].keys() if rows else ['url']); w.writeheader(); w.writerows(rows)
 else: out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf8')
 print(json.dumps({'saved':len(rows),'combos':st['combo'],'state':str(stp)},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/gdelt_worldcup.jsonl');p.add_argument('--limit',type=int,default=10000);p.add_argument('--sleep',type=float,default=1.2);p.add_argument('--restart',action='store_true');main(p.parse_args())
