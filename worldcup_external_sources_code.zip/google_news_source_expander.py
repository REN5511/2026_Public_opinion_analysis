#!/usr/bin/env python3
"""Source-targeted Google News RSS expansion using foreign publisher domains."""
import argparse, email.utils, json, time
from pathlib import Path
from urllib.parse import quote_plus
import requests
from bs4 import BeautifulSoup

ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup"],"2026世界杯":["2026 World Cup"],"美加墨世界杯":["World Cup 2026"],"FIFA世界杯":["FIFA World Cup"],"西班牙":["Spain","Spanish"],"乌拉圭":["Uruguay"],"沙特":["Saudi","Saudi Arabia"],"阿根廷":["Argentina","Argentine"],"小组赛":["group stage"],"32强":["round of 32","last 32","round-of-32"],"淘汰赛":["knockout stage","last 16","knockout rounds"],"晋级":["qualif","qualifier","qualified","advance","advanced"],"出线":["qualif","qualifier","qualified","advance","advanced"],"淘汰":["eliminat","elimination"],"加时":["extra time","aet"],"首战":["opening match","opening game"],"首秀":["debut","debuted"],"首次参赛":["first appearance","first ever appearance"],"首次世界杯":["first World Cup","maiden World Cup"]}
EX={"篮球世界杯":["Basketball World Cup"],"男篮世界杯":["Men's Basketball World Cup"],"女篮世界杯":["Women's Basketball World Cup"],"电竞世界杯":["Esports World Cup","eSports World Cup"],"王者世界杯":["Honor of Kings World Cup"],"女足世界杯":["Women's World Cup","Women's Football World Cup"],"U17世界杯":["U17 World Cup","U-17 World Cup"],"U20世界杯":["U20 World Cup","U-20 World Cup"],"世俱杯":["Club World Cup","FIFA Club World Cup"],"俱乐部世界杯":["Club World Cup","FIFA Club World Cup"]}
DOMAINS=['bbc.com','espn.com','skysports.com','bleacherreport.com','cnn.com','reuters.com','aljazeera.com','npr.org','nytimes.com','usatoday.com','foxsports.com','yahoo.com','yahoo.co.uk','si.com','cbssports.com','goal.com','theathletic.com','marca.com','as.com','mundodeportivo.com','lequipe.fr','dw.com','france24.com','apnews.com','washingtonpost.com','thetimes.co.uk','independent.co.uk','telegraph.co.uk','standard.co.uk','sportingnews.com','fourfourtwo.com','90min.com','beinsports.com','olympics.com','fifa.com','sports.yahoo.com','reddit.com','old.reddit.com','bigsoccer.com','football365.com','worldfootball.net','transfermarkt.com','soccerway.com','talksport.com','thisisfutbol.com','footballforums.net','forums.bigsoccer.com','theguardian.com','thehindu.com','hindustantimes.com','timesofindia.indiatimes.com','dailymail.co.uk','the-sun.com','mirror.co.uk','metro.co.uk','express.co.uk','eurosport.com','uefa.com','africanfootball.com','supersport.com','kickoff.com','sowetanlive.co.za','canadasoccer.com','mlssoccer.com','concacaf.com','foxdeportes.com','tycsports.com','ole.com.ar','record.pt','abola.pt','kicker.de','bild.de','corriere.it','gazzetta.it','rfi.fr','corrieredellosport.it','voetbalprimeur.nl','rtbf.be','sbs.com.au','abc.net.au','stuff.co.nz','espncricinfo.com']
def exp(xs,m):return list(dict.fromkeys(y for x in xs for y in [x,*m.get(x,[])]))
def hit(s,ws):return [w for w in ws if w.casefold() in (s or '').casefold().replace('’',"'")]
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8'));out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);sp=out.with_suffix('.state.json');st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'i':0,'rows':[],'urls':[]};subs=[x for x in exp(c['subject_keywords'],ALIASES) if x.isascii()];ev=[x for x in exp(c['event_keywords'],ALIASES) if x.isascii()];ex=exp(c['exclude_keywords'],EX)
 domains=[d.strip() for d in a.domains.split(',') if d.strip()] if a.domains else DOMAINS
 qs=[f'"{s}" "{e}" site:{d} after:{c["start_date"]} before:{c["end_date"]}' for d in domains for s in subs for e in ev]
 ses=requests.Session();ses.headers['User-Agent']='Mozilla/5.0 (compatible; source-expander/1.0)';
 if a.proxy:ses.proxies.update({'http':a.proxy,'https':a.proxy})
 while st['i']<len(qs) and len(st['rows'])<a.limit:
  q=qs[st['i']];u='https://news.google.com/rss/search?q='+quote_plus(q)+'&hl=en-US&gl=US&ceid=US:en'
  try:r=ses.get(u,timeout=45);r.raise_for_status();soup=BeautifulSoup(r.content,'xml')
  except Exception as e:print('request error',e);time.sleep(a.sleep*3);continue
  for it in soup.select('item'):
   title=it.title.get_text(' ',strip=True) if it.title else '';desc=BeautifulSoup(it.description.get_text() if it.description else '','html.parser').get_text(' ',strip=True);text=title+' '+desc;link=it.link.get_text(strip=True) if it.link else '';hs=hit(text,subs);he=hit(text,ev);bad=hit(text,ex)
   if not(link and hs and he and not bad) or link in st['urls']:continue
   pub=it.pubDate.get_text(strip=True) if it.pubDate else ''
   try:iso=email.utils.parsedate_to_datetime(pub).isoformat()
   except Exception:iso=pub
   src=it.select_one('source'); source=src.get_text(' ',strip=True) if src else 'Google News publisher search'; st['urls'].append(link);st['rows'].append({'record_type':'news_item','source':source,'url':link,'title':title,'published_at':iso,'description':desc,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':u})
   if len(st['rows'])>=a.limit:break
  st['i']+=1;sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8');time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'][:a.limit])+'\n',encoding='utf8');print(json.dumps({'saved':len(st['rows'][:a.limit]),'queries_completed':st['i'],'queries_total':len(qs)},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/google_news_source_expanded.jsonl');p.add_argument('--limit',type=int,default=10000);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.2);p.add_argument('--domains',help='Comma-separated publisher domains for an isolated expansion batch');p.add_argument('--restart',action='store_true');run(p.parse_args())
