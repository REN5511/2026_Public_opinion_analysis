import argparse, json
from urllib.parse import parse_qs, unquote, urlparse
from pathlib import Path

def canonical_url(url):
    query = parse_qs(urlparse(url or '').query)
    if 'bing.com/news/apiclick' in (url or '') and query.get('url'):
        return unquote(query['url'][0])
    return url

def main(a):
    seen=set(); rows=[]
    for name in a.inputs:
        p=Path(name)
        if not p.exists(): continue
        for line in p.read_text(encoding='utf8').splitlines():
            if not line.strip(): continue
            x=json.loads(line); u=canonical_url(x.get('url'))
            if u and u not in seen:
                seen.add(u)
                x['url'] = u
                if not x.get('source'):
                    x['source'] = urlparse(u).netloc or 'unknown'
                rows.append(x)
    Path(a.output).write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf8')
    print(json.dumps({'saved':len(rows),'inputs':a.inputs,'output':a.output},ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--inputs',nargs='+',required=True); p.add_argument('--output',required=True); main(p.parse_args())
