async page => {
  const config = {
    communities: ['soccer', 'football', 'MLS'],
    queries: [
      'Cape Verde World Cup',
      'Cabo Verde World Cup',
      'Vozinha World Cup',
      'Cape Verde Spain',
      'Cape Verde Uruguay',
      'Cape Verde Saudi',
      'Cape Verde Argentina'
    ],
    start: Date.parse('2026-05-28T00:00:00Z') / 1000,
    end: Date.parse('2026-07-27T00:00:00Z') / 1000,
    maxPagesPerQuery: 60,
    maxCommentsPerPost: 500,
    maxRows: 10000
  };

  return await page.evaluate(async cfg => {
    const subjects = ['Cape Verde', 'Cabo Verde', 'Vozinha'];
    const events = [
      'World Cup', '2026 World Cup', 'World Cup 2026', 'FIFA World Cup',
      'Spain', 'Spanish', 'Uruguay', 'Saudi', 'Saudi Arabia', 'Argentina',
      'group stage', 'round of 32', 'last 32', 'knockout stage',
      'qualif', 'advance', 'eliminat', 'extra time', 'opening match',
      'debut', 'first appearance', 'first World Cup'
    ];
    const excluded = [
      'Basketball World Cup', "Men's Basketball World Cup", "Women's Basketball World Cup",
      'Esports World Cup', 'eSports World Cup', 'Honor of Kings World Cup',
      "Women's World Cup", 'U17 World Cup', 'U-17 World Cup',
      'U20 World Cup', 'U-20 World Cup', 'Club World Cup',
      'FIFA Club World Cup', 'Mundial de Clubes', 'Copa do Mundo de Clubes'
    ];
    const norm = value => String(value || '').replace(/[’]/g, "'").toLocaleLowerCase();
    const hits = (value, words) => {
      const text = norm(value);
      return words.filter(word => text.includes(norm(word)));
    };
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    async function getJson(path) {
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          const response = await fetch(path, {
            credentials: 'include',
            headers: { Accept: 'application/json' }
          });
          if (response.ok) return await response.json();
          if (![429, 500, 502, 503, 504].includes(response.status)) return null;
        } catch (_) {}
        await sleep(1000 * (attempt + 1));
      }
      return null;
    }

    const parents = new Map();
    const stats = { searchPages: 0, searchChildren: 0, parentMatches: 0, commentRequests: 0 };
    for (const community of cfg.communities) {
      for (const query of cfg.queries) {
        let after = null;
        for (let pageNo = 0; pageNo < cfg.maxPagesPerQuery; pageNo++) {
          const params = new URLSearchParams({
            q: query, restrict_sr: '1', sort: 'new', t: 'all', limit: '100', raw_json: '1'
          });
          if (after) params.set('after', after);
          const listing = await getJson(`/r/${community}/search.json?${params}`);
          stats.searchPages++;
          const data = listing && listing.data;
          if (!data) break;
          const children = data.children || [];
          stats.searchChildren += children.length;
          let reachedOlder = false;
          for (const child of children) {
            if (child.kind !== 't3') continue;
            const post = child.data || {};
            const created = Number(post.created_utc || 0);
            if (created < cfg.start) reachedOlder = true;
            const text = `${post.title || ''} ${post.selftext || ''}`;
            const matchedSubjects = hits(text, subjects);
            const matchedEvents = hits(text, events);
            if (!post.name || created < cfg.start || created >= cfg.end || !matchedSubjects.length || !matchedEvents.length || hits(text, excluded).length) continue;
            if (!parents.has(post.name)) {
              parents.set(post.name, {
                id: post.name,
                subreddit: community,
                title: post.title || '',
                selftext: post.selftext || '',
                permalink: post.permalink || '',
                published_at: new Date(created * 1000).toISOString(),
                matched_subject_keywords: matchedSubjects,
                matched_event_keywords: matchedEvents
              });
              stats.parentMatches++;
            }
          }
          after = data.after || null;
          if (!after || reachedOlder) break;
          await sleep(450);
        }
      }
    }

    const rows = [];
    for (const parent of parents.values()) {
      if (rows.length >= cfg.maxRows) break;
      rows.push({
        record_type: 'forum_post', source: `Reddit r/${parent.subreddit}`, forum: 'Reddit',
        id: parent.id, url: `https://www.reddit.com${parent.permalink}`,
        title: parent.title, published_at: parent.published_at, bodyText: parent.selftext,
        matched_subject_keywords: parent.matched_subject_keywords,
        matched_event_keywords: parent.matched_event_keywords, excluded_keywords: [],
        discovery_url: `https://www.reddit.com/r/${parent.subreddit}/search.json`
      });
      const listing = await getJson(`${parent.permalink}.json?limit=${cfg.maxCommentsPerPost}&depth=10&raw_json=1`);
      stats.commentRequests++;
      const nodes = listing && listing[1] && listing[1].data ? listing[1].data.children || [] : [];
      const collect = items => {
        const found = [];
        for (const item of items || []) {
          if (item.kind !== 't1') continue;
          const comment = item.data || {};
          found.push(comment);
          const replies = comment.replies && comment.replies.data ? comment.replies.data.children : [];
          found.push(...collect(replies));
        }
        return found;
      };
      for (const comment of collect(nodes)) {
        if (rows.length >= cfg.maxRows) break;
        const created = Number(comment.created_utc || 0);
        const body = comment.body || '';
        const evidence = `${parent.title} ${parent.selftext} ${body}`;
        const matchedSubjects = hits(evidence, subjects);
        const matchedEvents = hits(evidence, events);
        if (!comment.name || created < cfg.start || created >= cfg.end || !body || !matchedSubjects.length || !matchedEvents.length || hits(evidence, excluded).length) continue;
        rows.push({
          record_type: 'forum_comment', source: `Reddit r/${parent.subreddit}`, forum: 'Reddit',
          id: comment.name, url: `https://www.reddit.com${comment.permalink || ''}`,
          parent_url: `https://www.reddit.com${parent.permalink}`, parent_title: parent.title,
          parent_publication_date: parent.published_at, published_at: new Date(created * 1000).toISOString(),
          bodyText: body, matched_subject_keywords: matchedSubjects,
          matched_event_keywords: matchedEvents, excluded_keywords: [],
          discovery_url: `https://www.reddit.com${parent.permalink}.json`
        });
      }
      await sleep(450);
    }
    return { rows, stats, parents: parents.size };
  }, config);
}
