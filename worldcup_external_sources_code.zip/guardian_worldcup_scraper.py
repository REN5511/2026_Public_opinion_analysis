#!/usr/bin/env python3
"""Batch scraper for Guardian football articles, opinion and liveblog content.

Uses the Guardian Open Platform Content API. Set GUARDIAN_API_KEY (the public
`test` key is enough for small dry runs). Progress is stored in state.json so
the job can be resumed safely after interruption.
"""
from __future__ import annotations
import argparse, csv, json, os, re, time
from pathlib import Path
from typing import Dict, Iterable, List
import requests

API = "https://content.guardianapis.com/search"
DEFAULTS = {
    "start_date": "2026-05-28", "end_date": "2026-07-26",
    "subject_keywords": ["佛得角", "沃齐尼亚"],
    "event_keywords": ["世界杯", "2026世界杯", "美加墨世界杯", "FIFA世界杯", "西班牙", "乌拉圭", "沙特", "阿根廷", "小组赛", "32强", "淘汰赛", "晋级", "出线", "淘汰", "加时", "首战", "首秀", "首次参赛", "首次世界杯"],
    "exclude_keywords": ["篮球世界杯", "男篮世界杯", "女篮世界杯", "电竞世界杯", "王者世界杯", "女足世界杯", "U17世界杯", "U20世界杯", "世俱杯", "俱乐部世界杯"],
}
# Guardian text is English; retain the supplied Chinese terms and add aliases.
ALIASES = {"佛得角": ["Cabo Verde", "Cape Verde"], "沃齐尼亚": ["Vozinha"], "世界杯": ["World Cup"], "2026世界杯": ["2026 World Cup"], "美加墨世界杯": ["World Cup 2026"], "FIFA世界杯": ["FIFA World Cup"], "西班牙": ["Spain", "Spanish"], "乌拉圭": ["Uruguay"], "沙特": ["Saudi Arabia", "Saudi"], "阿根廷": ["Argentina", "Argentine"], "小组赛": ["group stage"], "淘汰赛": ["knockout stage"], "晋级": ["qualif", "advance"], "出线": ["qualif", "advance"], "淘汰": ["eliminat"], "加时": ["extra time"], "首战": ["opening match"], "首秀": ["debut"], "首次参赛": ["first appearance"], "首次世界杯": ["first World Cup"], "篮球世界杯": ["Basketball World Cup"], "男篮世界杯": ["Men's Basketball World Cup"], "女篮世界杯": ["Women's Basketball World Cup"], "电竞世界杯": ["Esports World Cup", "eSports World Cup"], "王者世界杯": ["Honor of Kings World Cup"], "女足世界杯": ["Women's World Cup", "Women's Football World Cup"], "U17世界杯": ["U17 World Cup", "U-17 World Cup"], "U20世界杯": ["U20 World Cup", "U-20 World Cup"], "世俱杯": ["Club World Cup", "FIFA Club World Cup"], "俱乐部世界杯": ["Club World Cup", "FIFA Club World Cup"]}

def terms(words: Iterable[str]) -> List[str]:
    out = []
    for w in words:
        out.append(w); out.extend(ALIASES.get(w, []))
    return list(dict.fromkeys(out))

def contains_any(text: str, words: Iterable[str]) -> List[str]:
    # Guardian uses typographic apostrophes/dashes in body text.  Normalize
    # them so exclusion checks cannot be bypassed by punctuation variants.
    low = text.casefold().replace("’", "'").replace("‘", "'").replace("–", "-").replace("—", "-").replace("‑", "-")
    return [w for w in words if w.casefold().replace("’", "'").replace("‘", "'").replace("–", "-").replace("—", "-").replace("‑", "-") in low]

def load_config(path: str | None) -> Dict:
    cfg = DEFAULTS.copy()
    if path:
        cfg.update(json.loads(Path(path).read_text(encoding="utf-8")))
    return cfg

def fetch_page(session, api_key, cfg, query, page, page_size):
    params = {"api-key": api_key, "from-date": cfg["start_date"], "to-date": cfg["end_date"], "order-by": "oldest", "page": page, "page-size": page_size, "show-fields": "headline,trailText,bodyText,thumbnail", "show-tags": "all", "format": "json"}
    # Broad query gets enough candidates; local filtering applies exact include/exclude rules.
    params["q"] = query
    r = session.get(API, params=params, timeout=60); r.raise_for_status()
    return r.json()["response"]

def run(args):
    cfg = load_config(args.config); out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    state_path = out.with_suffix(".state.json")
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() and not args.restart else {"combo": 0, "page": 1, "ids": [], "rows": []}
    api_key = args.api_key or os.getenv("GUARDIAN_API_KEY", "test")
    event_terms = terms(cfg["event_keywords"])
    exclude = cfg["exclude_keywords"] + [x for k in cfg["exclude_keywords"] for x in ALIASES.get(k, [])]
    session = requests.Session(); session.headers["User-Agent"] = "guardian-worldcup-research/1.0"
    target = args.limit
    # Query one OR-group per subject family; local AND filtering still requires an event term.
    # This avoids multiplying requests by every English alias while retaining all candidates.
    combos = [s for s in cfg["subject_keywords"]]
    while len(state["rows"]) < target and state["combo"] < len(combos):
        s = combos[state["combo"]]; query_terms = terms([s]); query = " OR ".join('"' + x + '"' for x in query_terms)
        resp = fetch_page(session, api_key, cfg, query, state["page"], args.page_size)
        for item in resp.get("results", []):
            fields = item.get("fields", {}); tags = " ".join(t.get("webTitle", "") for t in item.get("tags", [])); text = " ".join([item.get("webTitle", ""), fields.get("headline", ""), fields.get("trailText", ""), tags, re.sub(r"<[^>]+>", " ", fields.get("bodyText", ""))])
            # Subject keywords use OR logic: any supplied subject or alias is sufficient.
            hit_subject = contains_any(text, terms(cfg["subject_keywords"])); hit_event = contains_any(text, event_terms); bad = contains_any(text, exclude)
            if hit_subject and hit_event and not bad and item["id"] not in state["ids"]:
                state["ids"].append(item["id"]); state["rows"].append({"id": item["id"], "type": item.get("type"), "webPublicationDate": item.get("webPublicationDate"), "webTitle": item.get("webTitle"), "url": item.get("webUrl"), "section": item.get("sectionName"), "matched_subject_keywords": hit_subject, "matched_event_keywords": hit_event, "trailText": fields.get("trailText", ""), "bodyText": fields.get("bodyText", "")})
                if len(state["rows"]) >= target: break
        state["page"] += 1
        if state["page"] > resp.get("pages", 0) or not resp.get("results"):
            state["combo"] += 1; state["page"] = 1
        state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        time.sleep(args.sleep)
    rows = state["rows"][:target]
    if out.suffix.lower() == ".csv":
        with out.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys() if rows else ["id"]); w.writeheader(); w.writerows(rows)
    else:
        out.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + ("\n" if rows else ""), encoding="utf-8")
    print(json.dumps({"saved": len(rows), "target": target, "next_page": state["page"], "state": str(state_path)}, ensure_ascii=False))

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--config"); p.add_argument("--output", default="data/guardian_worldcup.jsonl"); p.add_argument("--limit", type=int, default=10000); p.add_argument("--page-size", type=int, default=200); p.add_argument("--sleep", type=float, default=0.25); p.add_argument("--api-key"); p.add_argument("--restart", action="store_true"); run(p.parse_args())
