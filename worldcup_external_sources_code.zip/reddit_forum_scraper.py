#!/usr/bin/env python3
"""Collect non-domestic football-forum posts from Reddit RSS."""
import argparse,email.utils,json,time
from pathlib import Path
from urllib.parse import quote_plus
import requests
from bs4 import BeautifulSoup
ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup"],"2026世界杯":["2026 World Cup"],"美加墨世界杯":["World Cup 2026"],"FIFA世界杯":["FIFA World Cup"],"西班牙":["Spain","Spanish"],"乌拉圭":["Uruguay"],"沙特":["Saudi","Saudi Arabia"],"阿根廷":["Argentina","Argentine"],"小组赛":["group stage"],"32强":["round of 32"],"淘汰赛":["knockout stage"],"晋级":["qualif","advance"],"出线":["qualif","advance"],"淘汰":["eliminat"],"加时":["extra time"],"首战":["opening match"],"首秀":["debut"],"首次参赛":["first appearance"],"首次世界杯":["first World Cup"]}
EX={"篮球世界杯":["Basketball World Cup"],"男篮世界杯":["Men's Basketball World Cup"],"女篮世界杯":["Women's Basketball World Cup"],"电竞世界杯":["Esports World Cup","eSports World Cup"],"王者世界杯":["Honor of Kings World Cup"],"女足世界杯":["Women's World Cup","Women's Football World Cup"],"U17世界杯":["U17 World Cup","U-17 World Cup"],"U20世界杯":["U20 World Cup","U-20 World Cup"],"世俱杯":["Club World Cup","FIFA Club World Cup"],"俱乐部世界杯":["Club World Cup","FIFA Club World Cup"]}
def exp(xs,m):return list(dict.fromkeys(y for x in xs for y in [x,*m.get(x,[])]))
def hit(s,ws):return [w for w in ws if w.casefold() in (s or '').casefold().replace('’',"'")]
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8'));out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);sp=out.with_suffix('.state.json');st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'i':0,'rows':[],'urls':[]};subs=[s for s in exp(c['subject_keywords'],ALIASES) if s.isascii()];ev=[e for e in exp(c['event_keywords'],ALIASES) if e.isascii()];ex=exp(c['exclude_keywords'],EX);qs=[f'"{s}" "{e}" after:{c["start_date"]} before:{c["end_date"]}' for s in subs for e in ev];ses=requests.Session();ses.headers['User-Agent']='Mozilla/5.0 (compatible; football-research-rss/1.0)';
 if a.proxy:ses.proxies.update({'http':a.proxy,'https':a.proxy})
 while st['i']<len(qs) and len(st['rows'])<a.limit:
  q=qs[st['i']];u='https://www.reddit.com/r/soccer/search.rss?q='+quote_plus(q)+'&restrict_sr=1&sort=new&limit=100'
  try:r=ses.get(u,timeout=45);r.raise_for_status();soup=BeautifulSoup(r.content,'xml')
  except Exception as e:print('request error',e);time.sleep(a.sleep*3);continue
  for it in soup.find_all(['entry','item']):
   title=(it.title.get_text(' ',strip=True) if it.title else '');cont=(it.content.get_text(' ',strip=True) if it.content else (it.description.get_text(' ',strip=True) if it.description else ''));text=title+' '+cont;link=(it.link.get('href') if it.link and it.link.has_attr('href') else (it.link.get_text(strip=True) if it.link else ''));hs=hit(text,subs);he=hit(text,ev);bad=hit(text,ex)
   if not(link and hs and he and not bad) or link in st['urls']:continue
   pub=it.find(['updated','pubDate']);pub=pub.get_text(strip=True) if pub else ''
   try:iso=email.utils.parsedate_to_datetime(pub).isoformat()
   except Exception:iso=pub
   st['urls'].append(link);st['rows'].append({'record_type':'forum_post','source':'Reddit r/soccer','forum':'Reddit','url':link,'title':title,'published_at':iso,'bodyText':cont,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':u})
   if len(st['rows'])>=a.limit:break
  st['i']+=1;sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8');time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'][:a.limit])+'\n',encoding='utf8');print(json.dumps({'saved':len(st['rows'][:a.limit]),'queries_completed':st['i'],'queries_total':len(qs)},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/reddit_forum_strict.jsonl');p.add_argument('--limit',type=int,default=10000);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.5);p.add_argument('--restart',action='store_true');run(p.parse_args())
