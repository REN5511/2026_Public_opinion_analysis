#!/usr/bin/env python3
"""Audit and collect public Guardian reader discussions for strict parent pages.

Each saved comment retains its parent article URL, match evidence and the exact
public discussion JSON endpoint.  The job is resumable and sends all requests
through --proxy when supplied.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import time
from pathlib import Path

import requests
from bs4 import BeautifulSoup


DISCUSSION = "https://discussion.theguardian.com/discussion/{key}.json"


def load_jsonl(path: Path):
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def short_id(html: str) -> str | None:
    match = re.search(r'"shortUrlId"\s*:\s*"(/p/[A-Za-z0-9]+)"', html)
    return match.group(1) if match else None


def comment_records(payload: dict, parent: dict, endpoint: str):
    soup = BeautifulSoup(payload.get("commentsHtml", ""), "html.parser")
    for node in soup.select("[data-comment-id], .d-comment"):
        comment_id = node.get("data-comment-id")
        body = node.select_one(".d-comment__body, .d-comment-body") or node
        text = body.get_text(" ", strip=True)
        if comment_id and text:
            yield {
                "record_type": "reader_comment",
                "id": f"guardian-comment-{comment_id}",
                "comment_id": comment_id,
                "source": "The Guardian reader discussion",
                "url": parent["url"],
                "parent_url": parent["url"],
                "parent_title": parent.get("webTitle", ""),
                "parent_publication_date": parent.get("webPublicationDate", ""),
                "bodyText": text,
                "matched_subject_keywords": parent.get("matched_subject_keywords", []),
                "matched_event_keywords": parent.get("matched_event_keywords", []),
                "raw_response_url": endpoint,
            }


def run(args):
    parents = list(load_jsonl(Path(args.parents)))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    state_path = output.with_suffix(".state.json")
    state = (
        json.loads(state_path.read_text(encoding="utf-8"))
        if state_path.exists() and not args.restart
        else {"parent_index": 0, "checked": 0, "open_discussions": 0, "records": [], "seen": []}
    )
    session = requests.Session()
    session.headers["User-Agent"] = "guardian-worldcup-research/1.0"
    proxy = args.proxy or os.getenv("HTTPS_PROXY") or os.getenv("HTTP_PROXY")
    if proxy:
        session.proxies.update({"http": proxy, "https": proxy})

    while state["parent_index"] < len(parents) and len(state["records"]) < args.limit:
        parent = parents[state["parent_index"]]
        state["parent_index"] += 1
        try:
            page = session.get(parent["url"], timeout=45)
            page.raise_for_status()
        except requests.RequestException as exc:
            print(f"parent error: {parent['url']} {exc}")
            state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
            continue

        state["checked"] += 1
        if not re.search(r'allowUserGeneratedContent.{0,8}true', page.text):
            state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
            time.sleep(args.sleep)
            continue
        key = short_id(page.text)
        if not key:
            state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
            continue
        state["open_discussions"] += 1
        endpoint = DISCUSSION.format(key=key)
        page_number = 1
        while len(state["records"]) < args.limit:
            try:
                response = session.get(endpoint, params={"page": page_number, "pageSize": 50, "orderBy": "oldest", "displayThreaded": "true"}, timeout=45)
                response.raise_for_status()
                payload = response.json()
            except (requests.RequestException, ValueError) as exc:
                print(f"discussion error: {endpoint} {exc}")
                break
            added = 0
            for record in comment_records(payload, parent, response.url):
                if record["id"] not in state["seen"]:
                    state["seen"].append(record["id"])
                    state["records"].append(record)
                    added += 1
                    if len(state["records"]) >= args.limit:
                        break
            if page_number >= payload.get("lastPage", 1) or added == 0:
                break
            page_number += 1
            time.sleep(args.sleep)
        state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        time.sleep(args.sleep)

    output.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in state["records"]) + ("\n" if state["records"] else ""), encoding="utf-8")
    print(json.dumps({"parents_checked": state["checked"], "parents_total": len(parents), "open_discussions": state["open_discussions"], "comments_saved": len(state["records"]), "state": str(state_path)}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--parents", default="data/guardian_worldcup_strict_comments_v2.jsonl")
    parser.add_argument("--output", default="data/guardian_reader_comments_strict.jsonl")
    parser.add_argument("--limit", type=int, default=10000)
    parser.add_argument("--proxy")
    parser.add_argument("--sleep", type=float, default=0.25)
    parser.add_argument("--restart", action="store_true")
    run(parser.parse_args())
