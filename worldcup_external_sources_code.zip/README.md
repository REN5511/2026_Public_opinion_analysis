# Guardian 2026 世界杯体育数据抓取

参考 GitHub 项目：`clementbriens/guardian_headlines`（API 分页）和 `ahasan-haque/guardian_scraper`（文章字段提取）。本实现改为官方 Guardian Content API，支持分批、去重和断点续爬。严格模式要求同一篇文章同时命中至少一个主题词和一个事件词，并且不命中任何排除词；查询范围包含评论、专栏和实时博客。

```powershell
pip install requests
$env:GUARDIAN_API_KEY='你的 key'   # 可先用 test 做小规模验证
python guardian_worldcup_scraper.py --config config.json --limit 10000 --output data/guardian_worldcup_strict_comments_v2.jsonl
```

中断后重复同一命令即可从 `.state.json` 继续；如需重跑加 `--restart`。脚本不限制 `section=sport`，因此会纳入 Football、Opinion、实时博客（`liveblog`）及其他相关评论内容；输出字段包括内容类型、标题、发布时间、链接、命中关键词、摘要和正文。Guardian Content API 不提供普通读者评论线程，本数据集中的“评论”指 Guardian 编辑部的评论/专栏文章。API key 可在 `open-platform.theguardian.com/access` 申请；免费额度和检索结果量可能不足 10000，脚本会保存实际可获得数量并打印状态。

## X/Twitter 人工智能安全事件抓取

`x_ai_safety_scraper.py` 使用 `twscrape` 搜索事件相关根帖并抓取其直接一级回复。程序按天拆分检索，保留每页原始 GraphQL JSON，严格执行 `x_ai_safety_config.json` 中的三组必选词和排除词，按推文 ID、URL 与正文 SHA-256 去重，并可在中断后继续。

先安装依赖，再从已登录的 X 浏览器中复制 Cookie 请求头，其中至少应包含 `auth_token` 和 `ct0`。不要把 Cookie 写进命令历史或项目文件，使用交互式标准输入添加到本地账号库：

```powershell
pip install -r requirements-x.txt
twscrape --db data/x_ai_safety/accounts.db add_cookie local_x_account
```

先抓取 20 条做预检：

```powershell
python x_ai_safety_scraper.py --target 20
```

检查 `data/x_ai_safety/documents.jsonl` 与 `data/x_ai_safety/raw/` 后，继续完整任务：

```powershell
python x_ai_safety_scraper.py --target 10000
```

重复同一命令会从 `state.json` 继续。最终交付为 `event.json`（机器事实源）和由其生成的 `event.md`。如果账号池、时间窗口或公开讨论量不足，脚本会保存实际可获得数量，不会伪造到 10000 条。

## X/Twitter 人工智能安全事件抓取

`x_ai_safety_scraper.py` 使用 `twscrape` 搜索事件相关根帖并抓取其直接一级回复。程序按天拆分检索，保留每页原始 GraphQL JSON，严格执行 `x_ai_safety_config.json` 中的三组必选词和排除词，按推文 ID、URL 与正文 SHA-256 去重，并可在中断后继续。

先从已登录的 X 浏览器中复制 Cookie 请求头，其中至少应包含 `auth_token` 和 `ct0`。不要把 Cookie 写进命令历史或项目文件，使用交互式标准输入添加到本地账号库：

```powershell
twscrape --db data/x_ai_safety/accounts.db add_cookie local_x_account
```

然后先抓取 20 条做预检：

```powershell
python x_ai_safety_scraper.py --target 20
```

检查 `data/x_ai_safety/documents.jsonl` 与 `data/x_ai_safety/raw/` 后，继续完整任务：

```powershell
python x_ai_safety_scraper.py --target 10000
```

重复同一命令会从 `state.json` 继续。最终交付为 `event.json`（机器事实源）和由其生成的 `event.md`。如果账号池、时间窗口或公开讨论量不足，脚本会保存实际可获得数量，不会伪造到 10000 条。
