import argparse,json
from datetime import date
import re
from pathlib import Path
from urllib.parse import urlparse
DOMESTIC=('qq.com','news.qq.com','sohu.com','sina.com','sina.cn','163.com','126.com','baidu.com','toutiao.com','thepaper.cn','xinhuanet.com','people.com.cn','chinanews.com','huanqiu.com','ifeng.com','smzdm.com','weibo.com','douyin.com','bilibili.com','zhihu.com','tmall.com','taobao.com','chinadaily.com.cn','globaltimes.cn','cgtn.com','china.org.cn')
def main(a):
 start=date.fromisoformat(a.start_date); end=date.fromisoformat(a.end_date)
 out=[];seen=set()
 for line in Path(a.input).read_text(encoding='utf8').splitlines():
  if not line.strip():continue
  x=json.loads(line); src=(x.get('source') or '').casefold(); host=urlparse(x.get('url','')).netloc.casefold()
  raw=x.get('published_at') or x.get('webPublicationDate') or ''
  try: published=date.fromisoformat(raw[:10])
  except ValueError: continue
  if not start <= published <= end: continue
  if host.endswith('.cn') or any(d in src or d in host for d in DOMESTIC) or re.search(r'[\u4e00-\u9fff]', src):continue
  if x.get('url') not in seen:seen.add(x.get('url'));out.append(x)
 Path(a.output).write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in out)+'\n',encoding='utf8');print(json.dumps({'saved':len(out),'removed_domestic':sum(1 for _ in [])},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--start-date',default='2026-05-28');p.add_argument('--end-date',default='2026-07-26');main(p.parse_args())
