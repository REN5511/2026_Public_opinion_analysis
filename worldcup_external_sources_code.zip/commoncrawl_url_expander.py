#!/usr/bin/env python3
"""Discover candidate overseas URLs from Common Crawl indexes.

This stage only records candidates whose URL contains a date in the requested
window; page extraction is intentionally separate so crawl timestamps are not
mistaken for publication timestamps.
"""
import argparse,json,re,time,calendar
from pathlib import Path
from urllib.parse import quote
import requests

DOMAINS=['espn.com','theguardian.com','bbc.com','reuters.com','skysports.com','foxsports.com','yahoo.com','goal.com','beinsports.com','si.com','cbssports.com','apnews.com','aljazeera.com','nytimes.com']
SLUGS=['cape-verde','cabo-verde','vozinha']
def run(a):
 out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);seen=set();rows=[];s=requests.Session();s.headers['User-Agent']='Mozilla/5.0 commoncrawl-research/1.0'
 if a.proxy:s.proxies.update({'http':a.proxy,'https':a.proxy})
 for domain in DOMAINS:
  for slug in SLUGS:
   url=f'https://index.commoncrawl.org/{a.index}-index?url='+quote(f'*.{domain}/*{slug}*',safe='')+'&output=json&filter=status%3A200&collapse=urlkey'
   try:r=s.get(url,timeout=30,stream=True);r.raise_for_status()
   except Exception as e:print('request error',domain,slug,e);continue
   for raw in r.iter_lines(decode_unicode=True):
    line=raw or ''
    try:x=json.loads(line)
    except Exception:continue
    u=x.get('url',''); dates=re.findall(r'/(20\d{2})/(0[1-9]|1[0-2])/(\d{1,2})/',u)
    if not dates:
     m=re.search(r'/(20\d{2})/([a-z]{3,9})/(\d{1,2})/',u,re.I)
     if m:
      months={x.lower():i for i,x in enumerate(calendar.month_name) if x}; months.update({x.lower():i for i,x in enumerate(calendar.month_abbr) if x}); dates=[(m.group(1),str(months.get(m.group(2).lower(),0)),m.group(3))]
    if not dates or u in seen:continue
    y,m,d=map(int,dates[0]); iso=f'{y:04d}-{m:02d}-{d:02d}'
    if a.start<=iso<=a.end:
     seen.add(u);rows.append({'url':u,'source':'Common Crawl','index':a.index,'candidate_publication_date':iso,'matched_subject_keywords':['Cape Verde' if 'cape-verde' in u else 'Vozinha'],'discovery_url':url})
   out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf8')
   time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf8');print(json.dumps({'saved':len(rows),'output':str(out)},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--index',default='CC-MAIN-2026-30');p.add_argument('--start',default='2026-05-28');p.add_argument('--end',default='2026-07-26');p.add_argument('--output',default='data/commoncrawl_candidates.jsonl');p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.3);run(p.parse_args())
