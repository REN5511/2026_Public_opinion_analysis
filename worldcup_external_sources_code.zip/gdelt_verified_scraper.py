#!/usr/bin/env python3
"""Discover GDELT articles, then verify dates and keyword evidence on each origin page."""
import argparse
import concurrent.futures
import datetime as dt
import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from dateutil import parser as dateparser

API = "https://api.gdeltproject.org/api/v2/doc/doc"
SUBJECTS = [
    "Cape Verde", "Cabo Verde", "Cap-Vert", "Cap Vert", "Cabo-Verde",
    "Vozinha", "الرأس الأخضر", "كابو فيردي", "Кабо-Верде", "카보베르데",
]
EVENTS = [
    "World Cup", "FIFA World Cup", "World Cup 2026", "Copa do Mundo",
    "Mundial 2026", "Coupe du monde", "Mondial 2026", "مونديال",
    "كأس العالم", "Weltmeisterschaft", "Чемпионат мира", "월드컵",
    "Spain", "Uruguay", "Saudi Arabia", "Argentina", "Espanha", "Uruguai",
    "Arabia Saudita", "Espagne", "Espana", "group stage", "knockout stage",
    "qualification", "qualified", "debut", "first appearance", "extra time",
]
EXCLUDES = [
    "basketball world cup", "men's basketball world cup", "women's basketball world cup",
    "esports world cup", "honor of kings world cup", "women's world cup",
    "u17 world cup", "u-17 world cup", "u20 world cup", "u-20 world cup",
    "club world cup", "fifa club world cup", "mundial de clubes",
    "copa do mundo de clubes", "copa do mundo feminina", "mundial femenino",
]
DOMESTIC_HOSTS = (
    ".cn", "chinadaily", "globaltimes", "xinhuanet", "people.com.cn",
    "chinanews", "huanqiu", "thepaper", "qq.com", "sohu.com", "sina.com",
    "163.com", "baidu.com", "toutiao", "weibo.com", "bilibili.com", "zhihu.com",
)


def normal(value):
    return re.sub(r"\s+", " ", value or "").strip()


def hits(text, terms):
    haystack = (text or "").casefold().replace("’", "'")
    return [term for term in terms if term.casefold().replace("’", "'") in haystack]


def json_dates(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.casefold() in {"datepublished", "datecreated", "uploaddate"} and isinstance(item, str):
                yield item
            yield from json_dates(item)
    elif isinstance(value, list):
        for item in value:
            yield from json_dates(item)


def parse_published(raw):
    try:
        return dateparser.parse(raw, fuzzy=False).date().isoformat()
    except (TypeError, ValueError, OverflowError):
        return None


def extract_published(soup):
    attrs = [
        ("property", "article:published_time"), ("property", "og:published_time"),
        ("name", "article:published_time"), ("name", "date"), ("name", "pubdate"),
        ("name", "datePublished"), ("name", "parsely-pub-date"),
        ("itemprop", "datePublished"),
    ]
    for attr, name in attrs:
        node = soup.find("meta", attrs={attr: re.compile(f"^{re.escape(name)}$", re.I)})
        if node and parse_published(node.get("content")):
            return parse_published(node.get("content"))
    for node in soup.select('time[datetime]'):
        value = parse_published(node.get("datetime"))
        if value:
            return value
    for node in soup.select('script[type="application/ld+json"]'):
        try:
            payload = json.loads(node.get_text(strip=True))
        except json.JSONDecodeError:
            continue
        for raw in json_dates(payload):
            value = parse_published(raw)
            if value:
                return value
    return None


def verify(article, start, end, proxy):
    url = article.get("url", "")
    host = urlparse(url).netloc.casefold()
    if not url or any(token in host for token in DOMESTIC_HOSTS):
        return None
    session = requests.Session()
    session.headers["User-Agent"] = "Mozilla/5.0 (compatible; public-news-research/1.0)"
    if proxy:
        session.proxies.update({"http": proxy, "https": proxy})
    try:
        response = session.get(url, timeout=35, allow_redirects=True)
        response.raise_for_status()
    except requests.RequestException:
        return None
    resolved = response.url
    resolved_host = urlparse(resolved).netloc.casefold()
    if any(token in resolved_host for token in DOMESTIC_HOSTS):
        return None
    soup = BeautifulSoup(response.content, "html.parser")
    published = extract_published(soup)
    if not published:
        return None
    try:
        published_day = dt.date.fromisoformat(published)
    except ValueError:
        return None
    if not start <= published_day <= end:
        return None
    title = normal(soup.title.get_text(" ", strip=True) if soup.title else article.get("title", ""))
    body = normal(soup.get_text(" ", strip=True))
    evidence = title + " " + body
    subject_hits = hits(evidence, SUBJECTS)
    event_hits = hits(evidence, EVENTS)
    excluded = hits(evidence, EXCLUDES)
    if not subject_hits or not event_hits or excluded:
        return None
    return {
        "record_type": "news_item",
        "source": resolved_host,
        "url": resolved,
        "title": title,
        "published_at": published,
        "bodyText": body[:12000],
        "matched_subject_keywords": subject_hits,
        "matched_event_keywords": event_hits,
        "excluded_keywords": [],
        "discovery_source": "GDELT DOC 2.0",
        "discovery_url": article.get("url", ""),
        "gdelt_language": article.get("language"),
        "gdelt_sourcecountry": article.get("sourcecountry"),
    }


def main(args):
    start = dt.date.fromisoformat(args.start_date)
    end = dt.date.fromisoformat(args.end_date)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    state_file = output.with_suffix(".state.json")
    state = json.loads(state_file.read_text(encoding="utf8")) if state_file.exists() and not args.restart else {
        "query_index": 0, "candidates": [], "verified": [], "seen_candidates": [], "seen_urls": []
    }
    queries = [(subject, event) for subject in SUBJECTS for event in EVENTS]
    session = requests.Session()
    session.headers["User-Agent"] = "Mozilla/5.0 (compatible; public-news-research/1.0)"
    if args.proxy:
        session.proxies.update({"http": args.proxy, "https": args.proxy})
    while state["query_index"] < min(len(queries), args.max_queries) and len(state["candidates"]) < args.candidate_limit:
        subject, event = queries[state["query_index"]]
        params = {
            "query": f'"{subject}" "{event}"', "mode": "artlist", "maxrecords": 250,
            "format": "json", "sort": "datedesc",
            "startdatetime": start.strftime("%Y%m%d") + "000000",
            "enddatetime": end.strftime("%Y%m%d") + "235959",
        }
        try:
            payload = session.get(API, params=params, timeout=20).json()
        except (requests.RequestException, ValueError) as error:
            # An unavailable GDELT shard must not hold the whole batch forever.
            print(f"discovery skipped {state['query_index']}: {error}", flush=True)
            state["query_index"] += 1
            state_file.write_text(json.dumps(state, ensure_ascii=False), encoding="utf8")
            time.sleep(args.sleep * 2)
            continue
        for article in payload.get("articles", []):
            url = article.get("url", "")
            if url and url not in state["seen_candidates"]:
                state["seen_candidates"].append(url)
                state["candidates"].append(article)
                if len(state["candidates"]) >= args.candidate_limit:
                    break
        state["query_index"] += 1
        state_file.write_text(json.dumps(state, ensure_ascii=False), encoding="utf8")
        time.sleep(args.sleep)
    pending = [article for article in state["candidates"] if article.get("url") not in state["seen_urls"]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(verify, article, start, end, args.proxy) for article in pending]
        for future in concurrent.futures.as_completed(futures):
            try:
                row = future.result()
            except Exception:
                row = None
            if row and row["url"] not in state["seen_urls"]:
                state["seen_urls"].append(row["url"])
                state["verified"].append(row)
            state_file.write_text(json.dumps(state, ensure_ascii=False), encoding="utf8")
            if len(state["verified"]) >= args.limit:
                break
    rows = state["verified"][:args.limit]
    output.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + ("\n" if rows else ""), encoding="utf8")
    print(json.dumps({"candidates": len(state["candidates"]), "verified": len(rows), "queries": state["query_index"]}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/gdelt_verified_strict.jsonl")
    parser.add_argument("--start-date", default="2026-05-28")
    parser.add_argument("--end-date", default="2026-07-26")
    parser.add_argument("--limit", type=int, default=3000)
    parser.add_argument("--candidate-limit", type=int, default=2500)
    parser.add_argument("--max-queries", type=int, default=30)
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--proxy", default="http://127.0.0.1:7897")
    parser.add_argument("--sleep", type=float, default=0.4)
    parser.add_argument("--restart", action="store_true")
    main(parser.parse_args())
