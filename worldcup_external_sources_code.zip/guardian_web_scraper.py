#!/usr/bin/env python3
"""Scrape Guardian search-result and article web pages (no Content API key).

The scraper searches each subject alias, follows result links, extracts the
server-rendered article text (including liveblogs/opinion), then applies the
same strict local rule as the API scraper: at least one subject term AND one
event term, and no exclusion term. Progress is resumable via a JSON state file.
"""
from __future__ import annotations
import argparse, csv, json, os, re, time
from pathlib import Path
from typing import Iterable
from urllib.parse import quote_plus, urljoin, urlparse
import requests
from bs4 import BeautifulSoup

SEARCH = "https://www.theguardian.com/search"
BASE = "https://www.theguardian.com"
ALIASES = {"佛得角": ["Cape Verde", "Cabo Verde"], "沃齐尼亚": ["Vozinha"],
 "世界杯": ["World Cup"], "2026世界杯": ["2026 World Cup"], "美加墨世界杯": ["World Cup 2026"], "FIFA世界杯": ["FIFA World Cup"],
 "西班牙": ["Spain", "Spanish"], "乌拉圭": ["Uruguay"], "沙特": ["Saudi Arabia", "Saudi"], "阿根廷": ["Argentina", "Argentine"],
 "小组赛": ["group stage"], "32强": ["round of 32"], "淘汰赛": ["knockout stage"], "晋级": ["qualif", "advance"], "出线": ["qualif", "advance"], "淘汰": ["eliminat"], "加时": ["extra time"], "首战": ["opening match"], "首秀": ["debut"], "首次参赛": ["first appearance"], "首次世界杯": ["first World Cup"]}
DEFAULTS = {"start_date":"2026-05-28", "end_date":"2026-07-26", "subject_keywords":["佛得角","沃齐尼亚"], "event_keywords":["世界杯","2026世界杯","美加墨世界杯","FIFA世界杯","西班牙","乌拉圭","沙特","阿根廷","小组赛","32强","淘汰赛","晋级","出线","淘汰","加时","首战","首秀","首次参赛","首次世界杯"], "exclude_keywords":["篮球世界杯","男篮世界杯","女篮世界杯","电竞世界杯","王者世界杯","女足世界杯","U17世界杯","U20世界杯","世俱杯","俱乐部世界杯"]}

def expand(words: Iterable[str]):
    return list(dict.fromkeys(x for w in words for x in [w, *ALIASES.get(w, [])]))
def hits(text: str, words: Iterable[str]):
    low = text.casefold(); return [w for w in words if w.casefold() in low]
def in_range(dt: str, cfg):
    return bool(dt and cfg["start_date"] <= dt[:10] <= cfg["end_date"])
def article_text(soup):
    # Guardian uses article-body selectors across standard articles and liveblogs.
    node = soup.select_one("[data-gu-name='body']") or soup.select_one("article") or soup.body
    return " ".join(node.stripped_strings) if node else ""
def parse_listing(soup):
    links = []
    for a in soup.select("a[href]"):
        href = urljoin(BASE, a.get("href", "")).split("?")[0]
        p = urlparse(href)
        if p.netloc.endswith("theguardian.com") and re.match(r"^/(?:sport|football|commentisfree|world)/\d{4}/", p.path):
            if href not in links: links.append(href)
    return links
def run(args):
    cfg = DEFAULTS.copy(); cfg.update(json.loads(Path(args.config).read_text(encoding="utf-8")) if args.config else {})
    out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True); state_path = out.with_suffix(".state.json")
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() and not args.restart else {"listing":0,"page":1,"seen":[],"rows":[]}
    subjects, events = expand(cfg["subject_keywords"]), expand(cfg["event_keywords"])
    excludes = expand(cfg["exclude_keywords"])
    listings = ["football", "sport", "commentisfree", "world"]
    ses = requests.Session(); ses.headers.update({"User-Agent":"Mozilla/5.0 (research; guardian-web-scraper/1.0)","Accept-Language":"en-GB,en;q=0.8"})
    proxy = args.proxy or os.getenv("HTTPS_PROXY") or os.getenv("HTTP_PROXY")
    if proxy: ses.proxies.update({"http": proxy, "https": proxy})
    while state["listing"] < len(listings) and len(state["rows"]) < args.limit:
        listing = listings[state["listing"]]
        url = f"{BASE}/{listing}?page={state['page']}"
        try:
            r = ses.get(url, timeout=45); r.raise_for_status()
        except requests.RequestException as e:
            print(f"listing error: {e}"); time.sleep(args.sleep * 4); continue
        soup = BeautifulSoup(r.text, "html.parser"); links = parse_listing(soup)
        if not links:
            state["listing"] += 1; state["page"] = 1; state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8"); continue
        for link in links:
            if link in state["seen"]: continue
            state["seen"].append(link)
            try:
                ar = ses.get(link, timeout=45); ar.raise_for_status(); asoup = BeautifulSoup(ar.text, "html.parser")
            except requests.RequestException: continue
            meta = {m.get("property") or m.get("name"): m.get("content", "") for m in asoup.select("meta[content]")}
            dt = meta.get("article:published_time", "") or (asoup.select_one("time[datetime]") or {}).get("datetime", "")
            if not in_range(dt, cfg): continue
            title = meta.get("og:title", "") or (asoup.select_one("h1") or {}).get_text(" ", strip=True)
            text = title + " " + meta.get("description", "") + " " + article_text(asoup)
            hs, he, bad = hits(text, subjects), hits(text, events), hits(text, excludes)
            if hs and he and not bad:
                state["rows"].append({"url":link,"webTitle":title,"webPublicationDate":dt,"matched_subject_keywords":hs,"matched_event_keywords":he,"bodyText":text})
                if len(state["rows"]) >= args.limit: break
            time.sleep(args.sleep)
        state["page"] += 1; state_path.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        if state["page"] > args.max_pages: state["listing"] += 1; state["page"] = 1
    rows = state["rows"][:args.limit]
    if out.suffix.lower() == ".csv":
        with out.open("w", newline="", encoding="utf-8-sig") as f: csv.DictWriter(f, fieldnames=rows[0].keys() if rows else ["url"]).writeheader(); csv.DictWriter(f, fieldnames=rows[0].keys() if rows else ["url"]).writerows(rows)
    else: out.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + ("\n" if rows else ""), encoding="utf-8")
    print(json.dumps({"saved":len(rows),"seen":len(state["seen"]),"state":str(state_path)}, ensure_ascii=False))
if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--config"); p.add_argument("--output",default="data/guardian_web_strict.jsonl"); p.add_argument("--limit",type=int,default=10000); p.add_argument("--max-pages",type=int,default=100); p.add_argument("--sleep",type=float,default=.4); p.add_argument("--proxy",default=None,help="HTTP proxy, e.g. http://127.0.0.1:7897"); p.add_argument("--restart",action="store_true"); run(p.parse_args())
