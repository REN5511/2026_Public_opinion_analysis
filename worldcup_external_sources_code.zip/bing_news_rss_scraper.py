#!/usr/bin/env python3
"""Collect strict matches from Bing News RSS with publisher attribution."""
import argparse,email.utils,json,time
from pathlib import Path
from urllib.parse import parse_qs,quote_plus,unquote,urlparse
import requests
from bs4 import BeautifulSoup
ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup","Copa do Mundo","Copa Mundial","Mundial"],"2026世界杯":["2026 World Cup","Copa do Mundo 2026","Mundial 2026"],"美加墨世界杯":["World Cup 2026","Copa do Mundo 2026","Mundial 2026"],"FIFA世界杯":["FIFA World Cup","Copa do Mundo FIFA","Copa Mundial FIFA"],"西班牙":["Spain","Spanish","Espanha","Espana","Espana"],"乌拉圭":["Uruguay","Uruguai"],"沙特":["Saudi","Saudi Arabia","Arabia Saudita"],"阿根廷":["Argentina","Argentine","Argentina"],"小组赛":["group stage","fase de grupos","fase de grupos"],"32强":["round of 32","last 32","dieciseisavos"],"淘汰赛":["knockout stage","mata-mata","eliminatorias","eliminatorias"],"晋级":["qualif","advance","classific","avanc","clasific"],"出线":["qualif","advance","classific","avanc","clasific"],"淘汰":["eliminat","eliminacao","eliminacion"],"加时":["extra time","prorrogacao","prorroga"],"首战":["opening match","estreia","debut"],"首秀":["debut","estreia","debut"],"首次参赛":["first appearance","primeira participacao","primera participacion"],"首次世界杯":["first World Cup","primeira Copa do Mundo","primer Mundial"]}
ALIASES.update({
 "佛得角":["Cape Verde","Cabo Verde","Cap-Vert","Cap Vert","Kap Verde","Capo Verde","الرأس الأخضر","كابو فيردي","Кабо-Верде","카보베르데"],
 "世界杯":["World Cup","Copa do Mundo","Copa Mundial","Mundial","Coupe du monde","Mondial","Weltmeisterschaft","Coppa del Mondo","كأس العالم","مونديال"],
 "2026世界杯":["2026 World Cup","Copa do Mundo 2026","Mundial 2026","Coupe du monde 2026","Mondial 2026","Weltmeisterschaft 2026","Coppa del Mondo 2026","كأس العالم 2026"],
 "美加墨世界杯":["World Cup 2026","Copa do Mundo 2026","Mundial 2026","Coupe du monde 2026","Mondial 2026","Coppa del Mondo 2026"],
 "FIFA世界杯":["FIFA World Cup","Copa do Mundo FIFA","Copa Mundial FIFA","Coupe du monde de la FIFA","FIFA-Weltmeisterschaft","Coppa del Mondo FIFA","كأس العالم لكرة القدم"],
 "西班牙":["Spain","Spanish","Espanha","Espana","Espagne","Spanien","Spagna","إسبانيا"],
 "乌拉圭":["Uruguay","Uruguai","Uruguayen","Uruguaiano","أوروغواي"],
 "沙特":["Saudi","Saudi Arabia","Arabia Saudita","Arabie saoudite","Saudi-Arabien","Arabia Saudita","السعودية"],
 "小组赛":["group stage","fase de grupos","phase de groupes","Gruppenphase","fase a gironi","دور المجموعات"],
 "32强":["round of 32","last 32","dieciseisavos","seizièmes de finale","Sechzehntelfinale","sedicesimi","دور الـ32"],
 "淘汰赛":["knockout stage","mata-mata","eliminatorias","phase à élimination","K.-o.-Phase","fase a eliminazione","الأدوار الإقصائية"],
 "晋级":["qualif","advance","classific","avanc","clasific","qualifi","sich qualifiz","qualificaz","يتأهل"],
 "出线":["qualif","advance","classific","avanc","clasific","qualifi","sich qualifiz","qualificaz","يتأهل"],
 "淘汰":["eliminat","eliminacao","eliminacion","élimin","ausgeschieden","eliminaz","إقصاء"],
 "加时":["extra time","prorrogacao","prorroga","prolongation","Verlängerung","tempi supplementari","وقت إضافي"],
 "首战":["opening match","estreia","debut","match d'ouverture","Eröffnungsspiel","partita inaugurale","المباراة الافتتاحية"],
 "首秀":["debut","estreia","première","Debüt","esordio","ظهور أول"],
 "首次参赛":["first appearance","primeira participacao","primera participacion","première participation","erste Teilnahme","prima partecipazione","المشاركة الأولى"],
 "首次世界杯":["first World Cup","primeira Copa do Mundo","primer Mundial","première Coupe du monde","erste WM","prima Coppa del Mondo","أول كأس عالم"],
})
EX={"篮球世界杯":["Basketball World Cup","Copa do Mundo de Basquete","Mundial de Basquetebol","Copa Mundial de Baloncesto"],"男篮世界杯":["Men's Basketball World Cup","Mundial Masculino de Basquetebol","Mundial de Baloncesto Masculino"],"女篮世界杯":["Women's Basketball World Cup","Mundial Feminino de Basquetebol","Mundial de Baloncesto Femenino"],"电竞世界杯":["Esports World Cup","eSports World Cup","Copa do Mundo de Esports","Mundial de Esports"],"王者世界杯":["Honor of Kings World Cup","Copa do Mundo de Honor of Kings"],"女足世界杯":["Women's World Cup","Women's Football World Cup","Copa do Mundo Feminina","Mundial Femenino"],"U17世界杯":["U17 World Cup","U-17 World Cup","Mundial Sub-17","Mundial Sub 17"],"U20世界杯":["U20 World Cup","U-20 World Cup","Mundial Sub-20","Mundial Sub 20"],"世俱杯":["Club World Cup","FIFA Club World Cup","Mundial de Clubes","Copa do Mundo de Clubes"],"俱乐部世界杯":["Club World Cup","FIFA Club World Cup","Mundial de Clubes","Copa do Mundo de Clubes"]}
def exp(xs,m): return list(dict.fromkeys(y for x in xs for y in [x,*m.get(x,[])]))
def hit(s,ws): return [w for w in ws if w.casefold() in (s or '').casefold().replace('’',"'")]
def canonical_url(link):
 q=parse_qs(urlparse(link).query)
 return unquote(q['url'][0]) if 'bing.com/news/apiclick' in link and q.get('url') else link
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8')); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); sp=out.with_suffix('.state.json'); st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'i':0,'rows':[],'urls':[]}
 subs=exp(c['subject_keywords'],ALIASES); ev=exp(c['event_keywords'],ALIASES); ex=exp(c['exclude_keywords'],EX); qs=[f'"{s}" "{e}"' for s in subs for e in ev]; ses=requests.Session(); ses.headers['User-Agent']='Mozilla/5.0 research RSS collector/1.0';
 if a.proxy: ses.proxies.update({'http':a.proxy,'https':a.proxy})
 while st['i']<len(qs) and len(st['rows'])<a.limit:
  q=qs[st['i']]; u='https://www.bing.com/news/search?q='+quote_plus(q)+'&format=rss'+(f'&mkt={quote_plus(a.market)}' if a.market else '');
  try:r=ses.get(u,timeout=45); r.raise_for_status(); soup=BeautifulSoup(r.content,'xml')
  except Exception as e: print('request error',e); time.sleep(a.sleep*3); continue
  for it in soup.select('item'):
   title=it.title.get_text(' ',strip=True) if it.title else ''; desc=it.description.get_text(' ',strip=True) if it.description else ''; text=title+' '+desc; link=canonical_url(it.link.get_text(strip=True) if it.link else ''); hs=hit(text,subs); he=hit(text,ev); bad=hit(text,ex)
   if not(link and hs and he and not bad) or link in st['urls']: continue
   pub=it.pubDate.get_text(strip=True) if it.pubDate else ''
   try: iso=email.utils.parsedate_to_datetime(pub).isoformat()
   except Exception: iso=pub
   src=it.find(['News:Source','source']); source=src.get_text(' ',strip=True) if src else 'Bing News RSS'; st['urls'].append(link); st['rows'].append({'record_type':'news_item','source':source,'url':link,'title':title,'published_at':iso,'description':desc,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':u})
   if len(st['rows'])>=a.limit: break
  st['i']+=1; sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'][:a.limit])+'\n',encoding='utf8'); print(json.dumps({'saved':len(st['rows'][:a.limit]),'queries_completed':st['i'],'queries_total':len(qs)},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/bing_news_strict.jsonl');p.add_argument('--limit',type=int,default=10000);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.5);p.add_argument('--market',help='Bing market, for example pt-BR or es-MX');p.add_argument('--restart',action='store_true');run(p.parse_args())
