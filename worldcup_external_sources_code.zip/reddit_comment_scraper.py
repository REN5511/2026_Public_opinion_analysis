#!/usr/bin/env python3
"""Collect strict public Reddit soccer posts and comments with a user-supplied session cookie."""
import argparse, datetime, json, time
from pathlib import Path
from urllib.parse import quote
import requests

ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup","Copa do Mundo","Copa Mundial"],"2026世界杯":["2026 World Cup","Copa do Mundo 2026","Mundial 2026"],"美加墨世界杯":["World Cup 2026","Copa do Mundo 2026","Mundial 2026"],"FIFA世界杯":["FIFA World Cup","Copa do Mundo FIFA","Copa Mundial FIFA"],"西班牙":["Spain","Espanha","Espana"],"乌拉圭":["Uruguay","Uruguai"],"沙特":["Saudi","Saudi Arabia","Arabia Saudita"],"阿根廷":["Argentina"],"小组赛":["group stage","fase de grupos"],"32强":["round of 32","last 32","dieciseisavos"],"淘汰赛":["knockout stage","eliminatorias"],"晋级":["qualif","advance","classific"],"出线":["qualif","advance","classific"],"淘汰":["eliminat","eliminacion"],"加时":["extra time","prorroga"],"首战":["opening match","debut","estreia"],"首秀":["debut","estreia"],"首次参赛":["first appearance","primeira participacao"],"首次世界杯":["first World Cup","primeira Copa do Mundo"]}
EX=["Basketball World Cup","Men's Basketball World Cup","Women's Basketball World Cup","Esports World Cup","Honor of Kings World Cup","Women's World Cup","U17 World Cup","U-17 World Cup","U20 World Cup","U-20 World Cup","Club World Cup","FIFA Club World Cup","Mundial de Clubes","Copa do Mundo de Clubes","Copa do Mundo Feminina","Mundial Femenino"]
def exp(xs): return list(dict.fromkeys(y for x in xs for y in [x,*ALIASES.get(x,[])]))
def hit(text, words): return [w for w in words if w.casefold() in (text or '').casefold()]
def iso(ts): return datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat()
def walk_comments(nodes):
 for node in nodes or []:
  if node.get('kind') != 't1': continue
  data=node.get('data',{}); yield data
  replies=data.get('replies',{}); yield from walk_comments(replies.get('data',{}).get('children',[]) if isinstance(replies,dict) else [])
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8')); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); sp=out.with_suffix('.state.json')
 st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'q_index':0,'after':None,'parents':[],'parent_index':0,'rows':[],'seen':[]}
 subs=exp(c['subject_keywords']); ev=exp(c['event_keywords']); ex=EX+exp(c['exclude_keywords']); queries=[x for x in subs if x.isascii()]
 start=datetime.datetime.fromisoformat(c['start_date']).replace(tzinfo=datetime.timezone.utc).timestamp(); end=(datetime.datetime.fromisoformat(c['end_date'])+datetime.timedelta(days=1)).replace(tzinfo=datetime.timezone.utc).timestamp()
 cookie=Path(a.cookie_file).read_text(encoding='utf8').strip(); ses=requests.Session(); ses.headers.update({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36','Accept':'application/json','Cookie':cookie});
 if a.proxy: ses.proxies.update({'http':a.proxy,'https':a.proxy})
 communities=[x.strip() for x in a.communities.split(',') if x.strip()]
 # Discover parent posts. Stop each query once search pagination passes the time window.
 while st['q_index']<len(queries):
  q=queries[st['q_index']]
  for community in communities:
   after=st['after'] if st.get('after_community')==community else None
   while True:
    try:
     r=ses.get(f'https://www.reddit.com/r/{community}/search.json',params={'q':q,'restrict_sr':1,'sort':'new','t':'all','limit':100,'after':after,'raw_json':1},timeout=30); r.raise_for_status(); listing=r.json().get('data',{})
    except Exception:
     # The configured proxy can intermittently close persistent Reddit TLS connections.
     # Retry this read-only request once without it before abandoning the page.
     try:
      direct=requests.get(f'https://www.reddit.com/r/{community}/search.json',params={'q':q,'restrict_sr':1,'sort':'new','t':'all','limit':100,'after':after,'raw_json':1},headers=ses.headers,timeout=30); direct.raise_for_status(); listing=direct.json().get('data',{})
     except Exception: break
    children=listing.get('children',[]); older=False
    for child in children:
     p=child.get('data',{}); created=p.get('created_utc',0); text=(p.get('title','')+' '+p.get('selftext','')); hs=hit(text,subs); he=hit(text,ev)
     if created<start: older=True
     if start<=created<end and hs and he and not any(x.casefold() in text.casefold() for x in ex):
      key=p.get('name')
      if key and key not in {x['id'] for x in st['parents']}:
       st['parents'].append({'id':key,'permalink':p.get('permalink',''),'title':p.get('title',''),'selftext':p.get('selftext',''),'published_at':iso(created),'matched_subject_keywords':hs,'matched_event_keywords':he,'subreddit':community})
    after=listing.get('after'); st['after']=after; st['after_community']=community; sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8')
    if not after or older: break
    time.sleep(a.sleep)
   st['after']=None; st['after_community']=None
  st['q_index']+=1; sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8')
 # Extract comments from relevant parent posts. The matched unit is parent context plus comment body.
 while st['parent_index']<len(st['parents']) and len(st['rows'])<a.limit:
  parent=st['parents'][st['parent_index']]; st['parent_index']+=1
  try:
   r=ses.get('https://www.reddit.com'+parent['permalink']+'.json',params={'limit':500,'depth':10,'raw_json':1},timeout=30); r.raise_for_status(); payload=r.json(); nodes=payload[1].get('data',{}).get('children',[])
  except Exception:
   try:
    direct=requests.get('https://www.reddit.com'+parent['permalink']+'.json',params={'limit':500,'depth':10,'raw_json':1},headers=ses.headers,timeout=30); direct.raise_for_status(); payload=direct.json(); nodes=payload[1].get('data',{}).get('children',[])
   except Exception: sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); continue
  parent_text=parent['title']+' '+parent['selftext']
  for comment in walk_comments(nodes):
   body=comment.get('body',''); created=comment.get('created_utc',0); evidence=parent_text+' '+body; hs=hit(evidence,subs); he=hit(evidence,ev); cid=comment.get('name')
   if not(cid and start<=created<end and hs and he and not any(x.casefold() in evidence.casefold() for x in ex)) or cid in st['seen']: continue
   permalink=comment.get('permalink',''); st['seen'].append(cid); st['rows'].append({'record_type':'forum_comment','source':'Reddit r/'+parent['subreddit'],'forum':'Reddit','url':'https://www.reddit.com'+permalink,'parent_url':'https://www.reddit.com'+parent['permalink'],'parent_title':parent['title'],'parent_publication_date':parent['published_at'],'published_at':iso(created),'bodyText':body,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':'https://www.reddit.com/r/'+parent['subreddit']+'/search.json?q='+quote(parent['title'])})
   if len(st['rows'])>=a.limit: break
  sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'])+'\n',encoding='utf8'); print(json.dumps({'parents':len(st['parents']),'comments':len(st['rows']),'completed_parents':st['parent_index']},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--cookie-file',required=True);p.add_argument('--output',default='data/reddit_comments_strict.jsonl');p.add_argument('--communities',default='soccer,football,worldcup,MLS');p.add_argument('--limit',type=int,default=10000);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.5);p.add_argument('--restart',action='store_true');run(p.parse_args())
