#!/usr/bin/env python3
import argparse, datetime, html, json, re, time
from pathlib import Path
import requests

ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup","Copa do Mundo","Copa Mundial"],"2026世界杯":["2026 World Cup","Copa do Mundo 2026","Mundial 2026"],"美加墨世界杯":["World Cup 2026","Copa do Mundo 2026","Mundial 2026"],"FIFA世界杯":["FIFA World Cup","Copa do Mundo FIFA","Copa Mundial FIFA"],"西班牙":["Spain","Espanha","Espana"],"乌拉圭":["Uruguay","Uruguai"],"沙特":["Saudi","Saudi Arabia","Arabia Saudita"],"阿根廷":["Argentina"],"小组赛":["group stage","fase de grupos"],"32强":["round of 32","last 32","dieciseisavos"],"淘汰赛":["knockout stage","eliminatorias"],"晋级":["qualif","advance","classific"],"出线":["qualif","advance","classific"],"淘汰":["eliminat","eliminacion"],"加时":["extra time","prorroga"],"首战":["opening match","debut","estreia"],"首秀":["debut","estreia"],"首次参赛":["first appearance","primeira participacao"],"首次世界杯":["first World Cup","primeira Copa do Mundo"]}
EX=["Basketball World Cup","Men's Basketball World Cup","Women's Basketball World Cup","Esports World Cup","Honor of Kings World Cup","Women's World Cup","U17 World Cup","U-17 World Cup","U20 World Cup","U-20 World Cup","Club World Cup","FIFA Club World Cup","Mundial de Clubes","Copa do Mundo de Clubes","Copa do Mundo Feminina","Mundial Femenino"]
def exp(xs): return list(dict.fromkeys(y for x in xs for y in [x,*ALIASES.get(x,[])]))
def hit(s,ws): return [w for w in ws if w.casefold() in (s or '').casefold()]
def clean(s): return re.sub(r'<[^>]+>',' ',html.unescape(s or '')).replace('\\n',' ').strip()
def run(a):
 c=json.loads(Path(a.config).read_text(encoding='utf8')); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); sp=out.with_suffix('.state.json')
 st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'i':0,'rows':[],'seen':[]}
 subs=exp(c['subject_keywords']); ev=exp(c['event_keywords']); ex=EX+exp(c['exclude_keywords']); qs=subs
 ses=requests.Session(); ses.headers['User-Agent']='football-research-lemmy/1.0'; ses.proxies.update({'http':a.proxy,'https':a.proxy}) if a.proxy else None
 start=datetime.date.fromisoformat(c['start_date']); end=datetime.date.fromisoformat(c['end_date'])
 while st['i']<len(qs) and len(st['rows'])<a.limit:
  q=qs[st['i']]
  for inst in a.instances.split(','):
   try: data=ses.get(f'https://{inst}/api/v3/search',params={'q':q,'type_':'All','listing_type':'All','limit':50},timeout=30).json()
   except Exception: continue
   for kind,key in [('post','posts'),('comment','comments')]:
    for item in data.get(key,[]):
     obj=item.get(kind,{}) if isinstance(item,dict) else {}; text=clean((obj.get('name','')+' '+obj.get('body','')) if kind=='post' else obj.get('content','')); hs=hit(text,subs); he=hit(text,ev)
     if not(hs and he) or any(x.casefold() in text.casefold() for x in ex): continue
     pub=(obj.get('published') or '')[:10]
     try:
      if not start<=datetime.date.fromisoformat(pub)<=end: continue
     except ValueError: continue
     url=obj.get('ap_id') or obj.get('url'); uid=f'{inst}:{kind}:{obj.get("id")}'
     if not url or uid in st['seen']: continue
     st['seen'].append(uid); st['rows'].append({'record_type':'forum_comment' if kind=='comment' else 'forum_post','source':inst,'forum':'Lemmy','url':url,'title':obj.get('name','') if kind=='post' else '','published_at':obj.get('published'),'bodyText':text,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':f'https://{inst}/api/v3/search?q={q}'})
     if len(st['rows'])>=a.limit: break
  st['i']+=1; sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); time.sleep(a.sleep)
 out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in st['rows'][:a.limit])+'\n',encoding='utf8'); print(json.dumps({'saved':len(st['rows']),'queries':st['i']},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default='data/lemmy_forum_comments_strict.jsonl');p.add_argument('--instances',default='lemmy.world,programming.dev');p.add_argument('--limit',type=int,default=10000);p.add_argument('--proxy');p.add_argument('--sleep',type=float,default=.2);p.add_argument('--restart',action='store_true');run(p.parse_args())
