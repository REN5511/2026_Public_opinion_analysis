#!/usr/bin/env python3
"""Collect keyword-filtered records from Google News RSS (source is retained)."""
import argparse, csv, email.utils, json, time
from pathlib import Path
from urllib.parse import quote_plus
import requests
from bs4 import BeautifulSoup

ALIASES={"佛得角":["Cape Verde","Cabo Verde"],"沃齐尼亚":["Vozinha"],"世界杯":["World Cup"],"2026世界杯":["2026 World Cup"],"美加墨世界杯":["World Cup 2026"],"FIFA世界杯":["FIFA World Cup"],"西班牙":["Spain","Spanish"],"乌拉圭":["Uruguay"],"沙特":["Saudi","Saudi Arabia"],"阿根廷":["Argentina","Argentine"],"小组赛":["group stage"],"32强":["round of 32"],"淘汰赛":["knockout stage"],"晋级":["qualif","advance"],"出线":["qualif","advance"],"淘汰":["eliminat"],"加时":["extra time"],"首战":["opening match"],"首秀":["debut"],"首次参赛":["first appearance"],"首次世界杯":["first World Cup"]}
EXALIASES={"篮球世界杯":["Basketball World Cup"],"男篮世界杯":["Men's Basketball World Cup"],"女篮世界杯":["Women's Basketball World Cup"],"电竞世界杯":["Esports World Cup","eSports World Cup"],"王者世界杯":["Honor of Kings World Cup"],"女足世界杯":["Women's World Cup","Women's Football World Cup"],"U17世界杯":["U17 World Cup","U-17 World Cup"],"U20世界杯":["U20 World Cup","U-20 World Cup"],"世俱杯":["Club World Cup","FIFA Club World Cup"],"俱乐部世界杯":["Club World Cup","FIFA Club World Cup"]}
def expand(xs, amap): return list(dict.fromkeys(y for x in xs for y in [x,*amap.get(x,[])]))
def hits(s,ws):
    low=(s or '').casefold().replace('’',"'")
    return [w for w in ws if w.casefold().replace('’',"'") in low]
def run(a):
    cfg=json.loads(Path(a.config).read_text(encoding='utf8')); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); sp=out.with_suffix('.state.json')
    st=json.loads(sp.read_text(encoding='utf8')) if sp.exists() and not a.restart else {'query':0,'rows':[],'urls':[]}
    subs=expand(cfg['subject_keywords'],ALIASES); ev=expand(cfg['event_keywords'],ALIASES); ex=expand(cfg['exclude_keywords'],EXALIASES)
    # Query combinations broaden discovery while local rule remains authoritative.
    queries=[f'"{s}" "{e}" after:{cfg["start_date"]} before:{cfg["end_date"]}' for s in subs for e in ev]
    ses=requests.Session(); ses.headers['User-Agent']='Mozilla/5.0 (compatible; research RSS collector/1.0)'; proxy=a.proxy
    if proxy: ses.proxies.update({'http':proxy,'https':proxy})
    while st['query']<len(queries) and len(st['rows'])<a.limit:
        q=queries[st['query']]; url='https://news.google.com/rss/search?q='+quote_plus(q)+'&hl=en-US&gl=US&ceid=US:en'
        try: r=ses.get(url,timeout=45); r.raise_for_status(); soup=BeautifulSoup(r.content,'xml')
        except Exception as e: print('request error',e); time.sleep(a.sleep*3); continue
        for item in soup.select('item'):
            title=item.title.get_text(' ',strip=True) if item.title else ''
            desc=BeautifulSoup(item.description.get_text() if item.description else '','html.parser').get_text(' ',strip=True)
            text=title+' '+desc; hs=hits(text,subs); he=hits(text,ev); bad=hits(text,ex); link=item.link.get_text(strip=True) if item.link else ''
            if not (hs and he and not bad and link) or link in st['urls']: continue
            pub=item.pubDate.get_text(strip=True) if item.pubDate else ''
            try: iso=email.utils.parsedate_to_datetime(pub).isoformat()
            except Exception: iso=pub
            source=''; source_tag=item.select_one('source'); source=source_tag.get_text(' ',strip=True) if source_tag else ''
            st['urls'].append(link); st['rows'].append({'record_type':'news_item','source':source or 'Google News RSS','url':link,'title':title,'published_at':iso,'description':desc,'matched_subject_keywords':hs,'matched_event_keywords':he,'excluded_keywords':[],'discovery_url':url})
            if len(st['rows'])>=a.limit: break
        st['query']+=1; sp.write_text(json.dumps(st,ensure_ascii=False),encoding='utf8'); time.sleep(a.sleep)
    rows=st['rows'][:a.limit]; out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf8')
    print(json.dumps({'saved':len(rows),'queries_completed':st['query'],'queries_total':len(queries),'state':str(sp)},ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--output',default='data/google_news_strict.jsonl'); p.add_argument('--limit',type=int,default=10000); p.add_argument('--proxy'); p.add_argument('--sleep',type=float,default=.4); p.add_argument('--restart',action='store_true'); run(p.parse_args())
