#!/usr/bin/env node
// 探测 s.weibo.com 关键词搜索实际有多少页有内容（只抓 HTML，不抓详情/评论）
const fs = require("fs");
const path = require("path");
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const COOKIE = fs.readFileSync(path.join(__dirname, "cookies.txt"), "utf8").trim();
const QUERY = process.argv[2] || "世界杯佛得角";
const MAX = parseInt(process.argv[3] || "55", 10);
const TS = process.argv[4] || ""; // 形如 2026-05-28:2026-07-26
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let BASE = `https://s.weibo.com/weibo?q=${encodeURIComponent(QUERY)}&typeall=1&suball=1&Refer=g`;
if (TS) BASE += `&timescope=${encodeURIComponent("custom:" + TS)}`;
BASE += "&page=";
function countCards(html) {
  const re = /<div class="card-wrap" action-type="feed_list_item" mid="\d+"/g;
  let n = 0; while (re.exec(html)) n++;
  return n;
}
(async () => {
  let lastNonEmpty = 0, first = null, emptyStreak = 0;
  const rows = [];
  for (let page = 1; page <= MAX; page++) {
    const url = BASE + page;
    let html = null;
    try {
      const res = await fetch(url, { headers: { "User-Agent": UA, Referer: page > 1 ? BASE + (page - 1) : BASE + 1, Accept: "text/html,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9", Cookie: COOKIE } });
      if (res.status === 200) html = await res.text();
    } catch (e) { html = null; }
    if (!html) { console.log(`page ${page}: 抓取失败`); break; }
    const n = countCards(html);
    const emptyFlag = /抱歉|未找到|暂时没有相关|没有更多内容/.test(html);
    rows.push(`page ${page}: ${n} 帖${emptyFlag ? " [空页提示]" : ""}`);
    if (n > 0) { lastNonEmpty = page; if (!first) first = page; emptyStreak = 0; }
    else { emptyStreak++; if (emptyStreak >= 2) { rows.push(`连续 ${emptyStreak} 空页，停止`); break; } }
    console.log(rows[rows.length - 1]);
    await sleep(1500 + Math.random() * 900);
  }
  console.log(`\n结论: 关键词「${QUERY}」搜索到最后一页有内容的页码 = ${lastNonEmpty}`);
  fs.writeFileSync(path.join(__dirname, "out", "probe_result.txt"), rows.join("\n") + `\nlastNonEmpty=${lastNonEmpty}\n`, { flag: "a" });
})().catch((e) => { console.error(e); process.exit(1); });
