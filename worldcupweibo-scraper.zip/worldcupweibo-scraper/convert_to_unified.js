#!/usr/bin/env node
/**
 * 微博帖子数据 → 统一 JSON 转换器（格式对齐 data/README 描述的事件级统一 schema）
 *
 * 输入:  <in>/posts.ndjson    抓取/清洗后的原始逐帖数据(JSON Lines, 每行 {mid,page,card,detail,comments,error,ts})
 *        <in>/daily_heat.csv  每日热度档案(可选;缺失时按文档按日计数生成, total_reference 置 null)
 *        项目根 keywords.json 过滤规则(用于重算 matched_keywords)
 * 输出:  <out>/weibo_<event_id>.json
 *
 * 用法:
 *   node convert_to_unified.js                          # 默认 --in data --out data
 *   node convert_to_unified.js --in out/xxx --out data  # 重抓后从新的 out 目录生成交付 JSON
 *
 * 事件级常量与 YouTube 采集(evt_2026_fifa_world_cup_cape_verde)保持一致, 便于跨平台合并分析。
 * 时间口径: posts.ndjson 的 created_at 为微博站内时间(UTC+8), 写入统一 JSON 时转成 UTC ISO-8601。
 * 规范化规则(用于 content_text 与 content_hash, 幂等):
 *   移除 BOM;  \r\n 与 \r → \n;  去除首尾空白。
 */
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/* ---------- 事件级常量(与 YouTube 采集对齐) ---------- */
const EVENT_ID = "evt_2026_fifa_world_cup_cape_verde";
const EVENT_NAME = "2026年FIFA世界杯佛得角队相关舆情";
const SCHEMA_VERSION = "1.0.0";
const WINDOW = { start: "2026-05-28T00:00:00Z", endExclusive: "2026-07-27T00:00:00Z" };
const SOURCE_ID = "weibo";
const SOURCE_NAME = "微博";
const QUERY_TEXT = "世界杯佛得角";
const TIMESCOPE = "2026-05-28:2026-07-26"; // s.weibo.com custom timescope(北京日期)
const OUT_FILE = `weibo_${EVENT_ID}.json`;

/* ---------- CLI ---------- */
function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) a[k.slice(0, eq)] = k.slice(eq + 1);
      else a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true;
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const IN_DIR = ARG.in ? path.resolve(ROOT, ARG.in) : path.join(ROOT, "data");
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out) : IN_DIR;
const KEYWORDS_FILE = ARG.keywords ? path.resolve(ROOT, ARG.keywords) : path.join(ROOT, "keywords.json");

/* ---------- 小工具 ---------- */
const normText = (t) =>
  String(t == null ? "" : t)
    .replace(/\uFEFF/g, "")
    .replace(/\r\n?/g, "\n")
    .trim();
const sha256hex = (s) => crypto.createHash("sha256").update(s, "utf8").digest("hex");
// 微博站内时间 "YYYY-MM-DD HH:mm:ss"(UTC+8) → "YYYY-MM-DDTHH:mm:ssZ"(UTC)
const beijingToUtc = (s) => {
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(s))) return null;
  const d = new Date(String(s).replace(" ", "T") + "+08:00");
  return Number.isNaN(d.getTime()) ? null : d.toISOString().replace(/\.000Z$/, "Z");
};
const hasHan = (t) => /\p{Script=Han}/u.test(t);

function matchHits(text, kw) {
  const hay = text.toLowerCase();
  const hit = (words) => (Array.isArray(words) ? words.filter((w) => w && hay.includes(String(w).toLowerCase())) : []);
  return { subject: hit(kw.subject), event: hit(kw.event), exclude: hit(kw.exclude) };
}

/* ---------- 读取输入 ---------- */
const NDJSON = path.join(IN_DIR, "posts.ndjson");
if (!fs.existsSync(NDJSON)) {
  console.error(`未找到 ${NDJSON}\n用法: node convert_to_unified.js --in <含 posts.ndjson 的目录> [--out <交付目录>]`);
  process.exit(1);
}
const KEYWORDS = JSON.parse(fs.readFileSync(KEYWORDS_FILE, "utf8"));
const lines = fs.readFileSync(NDJSON, "utf8").split("\n").filter((l) => l.trim());
const dailyHeatCsv = path.join(IN_DIR, "daily_heat.csv");

/* ---------- 逐行转换 ---------- */
const documents = [];
const failedItems = [];
const seenMids = new Set();
const dupMids = [];
const perDay = {};
const textGroups = new Map(); // normText -> count, 用于重复文本组统计
let collectedAt = null; // 最后一条的抓取 ts(UTC)

for (const line of lines) {
  let p = null;
  try { p = JSON.parse(line); } catch (e) { failedItems.push({ object_id: "?unknown?", stage: "parse", reason: "posts.ndjson 行无法解析: " + e.message }); continue; }
  if (p.ts && (!collectedAt || p.ts > collectedAt)) collectedAt = p.ts;
  const detail = p.detail || null;

  if (!detail || !detail.mid) {
    failedItems.push({ object_id: p.mid || null, stage: "detail", reason: "缺少 detail 或 mid" });
    continue;
  }
  if (seenMids.has(detail.mid)) dupMids.push(detail.mid);
  seenMids.add(detail.mid);

  const mid = detail.mid;
  const topics = Array.isArray(detail.topics) ? detail.topics : [];
  const textRaw = detail.text || (p.card && p.card.text) || "";
  const contentText = normText(textRaw);
  const hay = contentText + "\n" + topics.join("\n");
  const hits = matchHits(hay, KEYWORDS);
  if (hits.exclude.length) console.warn(`[排除词命中] mid=${mid} exclude=${hits.exclude.join("/")} —— 该帖本应被关键词规则过滤`);
  const matchedKeywords = [...hits.subject, ...hits.event];

  const publishedAt = beijingToUtc(detail.created_at);
  const dayKey = String(detail.created_at || "").slice(0, 10); // 北京日期
  if (dayKey.length === 10) perDay[dayKey] = (perDay[dayKey] || 0) + 1;
  textGroups.set(contentText, (textGroups.get(contentText) || 0) + 1);

  const docId = `weibo:${mid}`;
  const card = p.card || {};
  documents.push({
    doc_id: docId,
    doc_type: "post",
    source_id: SOURCE_ID,
    source_name: SOURCE_NAME,
    platform_object_id: mid,
    canonical_url: detail.url || null,
    published_at: publishedAt,
    content_text: contentText,
    language: hasHan(contentText) ? "zh" : null,
    raw_path: null, // 微博为网页搜索抓取, 无脱敏 API 响应存档; 证据以在线链接与本地统一 JSON 为准
    content_hash: sha256hex(contentText),
    query_ids: ["q001"],
    matched_keywords: matchedKeywords,
    metrics: {
      reposts_count: Number.isFinite(Number(detail.reposts_count)) ? Number(detail.reposts_count) : null,
      comments_count: Number.isFinite(Number(detail.comments_count)) ? Number(detail.comments_count) : null,
      attitudes_count: Number.isFinite(Number(detail.attitudes_count)) ? Number(detail.attitudes_count) : null,
    },
    duplicate_of: null,
    parent_doc_id: null,
    root_doc_id: docId,
    thread_id: `weibo:${mid}`,
    extra: {
      mblogid: detail.mblogid || null,
      page: Number.isFinite(Number(p.page)) ? Number(p.page) : null,
      rank_in_page: Number.isFinite(Number(card.rank_in_page)) ? Number(card.rank_in_page) : null,
      time_display: card.time_display || null,
      created_at_display: detail.created_at_display || null,
      source: detail.source || null,           // 发布客户端
      region_name: detail.region_name || null, // 发布地区
      is_long_text: detail.isLongText == null ? null : !!detail.isLongText,
      text_html: detail.text_html || null,     // 原始 HTML 正文(证据快照)
      topics,
      pics: Array.isArray(detail.pics) ? detail.pics : [],
      pic_num: Number.isFinite(Number(detail.pic_num)) ? Number(detail.pic_num) : null,
      video: detail.video || null,
      search_card: {
        nick: card.nick || null,
        verified_title: card.verified_title || null,
        vip_level: card.vip_level == null ? null : card.vip_level,
        text: (card.text && normText(card.text)) || null,
        page_display: { 转发: card["page_转"] || null, 评论: card["page_评"] || null, 赞: card["page_赞"] || null },
      },
      author: detail.user || null, // 公开帖文作者资料, 保留原文(昵称/uid/认证/粉丝等)
      scraped_at: p.ts || null,    // 该帖被抓取落盘的 UTC 时间
    },
  });
}

/* ---------- daily_heat ---------- */
function parseHeatCsv(file) {
  const rows = [];
  for (const lineRaw of fs.readFileSync(file, "utf8").split("\n")) {
    const line = lineRaw.replace(/^\uFEFF/, "").trim();
    if (!line || line.startsWith("日期,")) continue;
    const c = line.split(",");
    if (c.length < 3) continue;
    const refRaw = (c[1] || "").trim();
    const m = refRaw.match(/^(\d+)$/);
    rows.push({
      date: c[0].trim(),
      total_reference: m ? Number(m[1]) : null,
      total_reference_raw: refRaw,
      is_overflow: !m && /≥500|>=500/.test(refRaw),
      final_sample: Number((c[2] || "").trim()) || 0,
    });
  }
  return rows;
}
let dailyHeat = [];
if (fs.existsSync(dailyHeatCsv)) {
  dailyHeat = parseHeatCsv(dailyHeatCsv);
  for (const h of dailyHeat) {
    if ((perDay[h.date] || 0) !== h.final_sample) {
      console.warn(`[daily_heat 不一致] ${h.date}: csv=${h.final_sample} 实际=${perDay[h.date] || 0}`);
    }
  }
} else {
  dailyHeat = Object.keys(perDay).sort().map((d) => ({ date: d, total_reference: null, total_reference_raw: null, is_overflow: false, final_sample: perDay[d] }));
  console.warn(`未找到 ${dailyHeatCsv}, daily_heat 按文档按日计数生成(total_reference 为 null)`);
}

/* ---------- 重复文本组 ---------- */
const duplicateTextGroups = [...textGroups.values()].filter((n) => n > 1).length;

/* ---------- 汇总字段 ---------- */
const queries = [{
  query_id: "q001",
  q: QUERY_TEXT,
  timescope: TIMESCOPE, // 微博平台附加字段: s.weibo.com 时间窗(北京日期)
  relevance_language: null, // 微博检索无语种提示(不适用)
  orders: [],               // 微博无多排序参数, 使用平台综合排序(不适用)
  unique_candidates: seenMids.size, // 该检索式召回的去重候选帖数(清洗后)
}];

const stats = {
  document_counts: documents.reduce((acc, d) => { acc[d.doc_type] = (acc[d.doc_type] || 0) + 1; return acc; }, {}),
  documents_total: documents.length,
  unique_object_ids: seenMids.size,
  duplicate_mids: dupMids.length,
  duplicate_text_groups: duplicateTextGroups,
  daily_heat: dailyHeat,
  collection_order: "weibo_search_default", // 平台综合排序(相关性+热度)
  sampling: {
    method: "density_proportional_daily_cap",
    note: "低热度日(真实量≤10)全量保留; 中/高密度日按天保留最新≤30 条, 与真实日量同比例(详见 daily_heat)",
    is_complete_comment_set: false,
  },
  comments: { mode: "off", note: "本次只采集帖子, 未采集评论(comments.csv 为空表头)" },
  filtering: {
    rule_file: path.relative(ROOT, KEYWORDS_FILE),
    applied: true,
    subject: KEYWORDS.subject,
    event: KEYWORDS.event,
    exclude: KEYWORDS.exclude,
    note: "每条帖子须含≥1主题词且≥1事件词且不含排除词; 关键词过滤在采集/清洗阶段执行",
  },
  failed_count: failedItems.length,
  conversion: {
    script: "convert_to_unified.js",
    input: path.relative(ROOT, NDJSON),
    run_at: new Date().toISOString(),
    normalization_note: "content_text: 去BOM, \\r\\n→\\n, 去首尾空白; content_hash = SHA-256(content_text)",
    timezone_note: "created_at 为微博站内时间(UTC+8), published_at 已转 UTC ISO-8601",
  },
};

const output = {
  schema_version: SCHEMA_VERSION,
  event_id: EVENT_ID,
  event_name: EVENT_NAME,
  collected_at: collectedAt || null, // 最后一条帖子抓取落盘时刻(UTC)
  collection_window: WINDOW,
  queries,
  documents,
  failed_items: failedItems,
  stats,
};

/* ---------- 自检 ---------- */
const inWindow = (iso) => iso && iso >= WINDOW.start && iso < WINDOW.endExclusive;
let hashOk = 0, windowOk = 0, kwOk = 0;
for (const d of documents) {
  if (sha256hex(normText(d.content_text)) === d.content_hash) hashOk++;
  if (inWindow(d.published_at)) windowOk++;
  if (d.matched_keywords.length && KEYWORDS.subject.some((w) => d.matched_keywords.includes(w)) && KEYWORDS.event.some((w) => d.matched_keywords.includes(w))) kwOk++;
}
const check = {
  documents: documents.length,
  hash_consistent: `${hashOk}/${documents.length}`,
  in_window: `${windowOk}/${documents.length}`,
  matched_kw_ok: `${kwOk}/${documents.length}`,
  doc_ids_unique: new Set(documents.map((d) => d.doc_id)).size === documents.length,
  daily_heat_sum: dailyHeat.reduce((s, h) => s + h.final_sample, 0),
  daily_heat_days: dailyHeat.length,
  failed_items: failedItems.length,
  duplicate_mids: dupMids,
};
console.log("自检:", JSON.stringify(check, null, 2));

/* ---------- 写文件 ---------- */
fs.mkdirSync(OUT_DIR, { recursive: true });
const outPath = path.join(OUT_DIR, OUT_FILE);
const tmpPath = outPath + ".tmp";
fs.writeFileSync(tmpPath, JSON.stringify(output, null, 2), "utf8");
fs.renameSync(tmpPath, outPath);
console.log(`已写入 ${outPath} (${(fs.statSync(outPath).size / 1024 / 1024).toFixed(2)} MB)`);
