#!/usr/bin/env node
/**
 * 数据清洗: 对已有 posts.ndjson 应用「时间范围 + 关键词 + 每日上限」规则并重写。
 * 与 scraper_batch.js 的 shouldKeep 逻辑一致，用于:
 *   1) 把改造前抓到的数据统一清洗(剔除越界/无关/超日上限的帖子);
 *   2) 全部抓取完成后做最终收尾(排序 + 再校验)。
 *
 * 用法:
 *   node clean_data.js --out <目录> [--from 2026-05-28 --to 2026-07-26]
 *                      [--daily-cap 1000] [--no-filter] [--keywords <json>]
 */
const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) a[k.slice(0, eq)] = k.slice(eq + 1);
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out) : null;
if (!OUT_DIR || !fs.existsSync(path.join(OUT_DIR, "posts.ndjson"))) { console.error("用法: node clean_data.js --out <目录>"); process.exit(1); }
const FROM = ARG.from || "2026-05-28";
const TO = ARG.to || "2026-07-26";
const DAILY_CAP = parseInt(ARG["daily-cap"] || "1000", 10);
const KEYWORDS = ARG["no-filter"] ? null : (() => {
  const f = ARG.keywords ? path.resolve(ROOT, ARG.keywords) : path.join(ROOT, "keywords.json");
  try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { console.warn(`未找到关键词文件 ${f}，跳过关键词过滤`); return null; }
})();

const FILE = path.join(OUT_DIR, "posts.ndjson");

function matchKeywords(text, kw) {
  const t = text.toLowerCase();
  if (kw.exclude && kw.exclude.length && kw.exclude.some((w) => t.includes(String(w).toLowerCase()))) return { ok: false, reason: "排除词" };
  if (kw.subject && kw.subject.length && !kw.subject.some((w) => t.includes(String(w).toLowerCase()))) return { ok: false, reason: "缺主题词" };
  if (kw.event && kw.event.length && !kw.event.some((w) => t.includes(String(w).toLowerCase()))) return { ok: false, reason: "缺事件词" };
  return { ok: true };
}

const lines = fs.readFileSync(FILE, "utf8").split("\n").filter((l) => l.trim());
const posts = [];
const dropBy = { 越界: 0, 排除词: 0, 缺主题词: 0, 缺事件词: 0, 详情失败: 0, 日上限: 0, 解析失败: 0 };
for (const ln of lines) {
  let o;
  try { o = JSON.parse(ln); } catch (e) { dropBy["解析失败"]++; continue; }
  const d = o.detail;
  const t = d && d.created_at;
  if (!t) { dropBy["详情失败"]++; continue; }
  const day = t.slice(0, 10);
  if (day < FROM || day > TO) { dropBy["越界"]++; continue; }
  if (KEYWORDS) {
    const text = ((d.text || "") + " " + (d.topics || []).join(" "));
    const r = matchKeywords(text, KEYWORDS);
    if (!r.ok) { dropBy[r.reason]++; continue; }
  }
  posts.push(o);
}
// 按时间倒序(新→旧)，无时间戳(上面已滤)不会出现; 同时间按 mid 稳定
posts.sort((a, b) => {
  const ta = a.detail.created_at, tb = b.detail.created_at;
  if (ta !== tb) return ta < tb ? 1 : -1;
  return a.mid < b.mid ? 1 : -1;
});
// 每日上限(保留每天最新 DAILY_CAP 条)
const daySeen = new Map();
const kept = [];
if (DAILY_CAP > 0) {
  for (const p of posts) {
    const day = p.detail.created_at.slice(0, 10);
    const c = daySeen.get(day) || 0;
    if (c >= DAILY_CAP) { dropBy["日上限"]++; continue; }
    daySeen.set(day, c + 1);
    kept.push(p);
  }
} else { kept.push(...posts); }

const before = lines.length;
fs.writeFileSync(FILE + ".tmp", kept.map((p) => JSON.stringify(p)).join("\n") + "\n", "utf8");
fs.renameSync(FILE + ".tmp", FILE);

const byDay = {};
for (const p of kept) { const k = p.detail.created_at.slice(0, 10); byDay[k] = (byDay[k] || 0) + 1; }
console.log(`清洗完成 → ${OUT_DIR}`);
console.log(`  原 ${before} 行 → 保留 ${kept.length} 行`);
console.log(`  剔除: ${Object.entries(dropBy).filter(([, n]) => n > 0).map(([k, n]) => `${k}=${n}`).join(" ")}`);
console.log(`  时间范围 ${FROM}~${TO} | 每日上限 ${DAILY_CAP} | 关键词过滤 ${KEYWORDS ? "开" : "关"}`);
console.log("  按日: " + Object.keys(byDay).sort().map((k) => `${k}=${byDay[k]}`).join(" "));
console.log(`  最旧 ${kept.length ? kept[kept.length - 1].detail.created_at : "-"} | 最新 ${kept.length ? kept[0].detail.created_at : "-"}`);
