# 世界杯佛得角 · 微博帖子数据包（最终交付）

关键词「世界杯佛得角」搜索结果的**帖子数据集**（不含评论），时间范围 **2026-05-28 ~ 2026-07-26**，
统一抽样口径、按日去重、按关键词过滤，共 **1270 条**。

## 目录结构

```
weibo-scraper-final/
├── data/                     ← 最终生成结果（唯一交付数据：统一格式 JSON，见下）
├── convert_to_unified.js     格式转换：posts.ndjson → data/ 统一 JSON（唯一写 data/ 的脚本）
├── scraper_batch.js          主爬虫：抓取单帖详情 + 关键词过滤(--filter) + 每日上限(--daily-cap)
├── scraper_windows.js        滑动时间窗驱动：突破单次搜索 50 页上限，窗口级断点续爬(--stop-at 分片)
├── sample_by_density.js      按密度比例抽样：读密度探测档案，为每天分配与真实量成比例的抓取预算
├── density_probe.js          密度探测：逐日请求解析「共X页/Y条」，输出每日真实总量档案
├── clean_data.js             清洗：时间范围 + 关键词 + 每日上限 + 排序，重写 posts.ndjson
├── sample_windows.js         时间均匀抽样驱动（早期工具，本数据包未使用）
├── page_probe.js             页数探测工具（早期工具）
├── keywords.json             过滤规则（主题词/事件词/排除词）
├── cookies.txt               微博登录 Cookie（过期后只改这一个文件）
└── README.md
```

## data/ 内容

`data/` 只保留一个事件级**统一 JSON**（格式与 YouTube 采集项目的最终数据一致，可跨平台合并分析）：

```text
data/weibo_evt_2026_fifa_world_cup_cape_verde.json   ← 唯一交付文件
```

顶层结构（schema_version 1.0.0，event 与 YouTube 采集共用 `evt_2026_fifa_world_cup_cape_verde`）：

| 键 | 说明 |
|---|---|
| `collection_window` | 事件级 UTC 窗口 `[2026-05-28T00:00:00Z, 2026-07-27T00:00:00Z)`，全部文档落于其内 |
| `queries` | 检索式记录：`q=世界杯佛得角`、`timescope=2026-05-28:2026-07-26`（北京日期）、`unique_candidates=1270` |
| `documents` | 1270 条帖子，`doc_type=post`、`source_id=weibo`，含全部通用字段 |
| `failed_items` | `[]`（1270 帖详情全部抓取成功） |
| `stats` | 文档计数、每日热度档案、抽样口径、关键词过滤规则、转换说明 |

### 帖子文档字段

- 通用字段：`doc_id`（`weibo:<mid>`，唯一）、`platform_object_id`（mid）、`canonical_url`（原帖链接）、
  `published_at`（UTC ISO-8601，由微博站内时间 UTC+8 转换）、`content_text`（规范化正文，长文已补全）、
  `language`、`raw_path`（null：微博为网页抓取，无脱敏 API 响应存档）、
  `content_hash`（`content_text` 的 SHA-256，用于一致性/去重）、`query_ids`、`matched_keywords`（命中的主题词+事件词）、
  `metrics`（转发/评论/赞数）、`duplicate_of`（null）。
- 关系字段：`parent_doc_id=null`、`root_doc_id=自身 doc_id`、`thread_id=weibo:<mid>`（本次只采集帖子，无评论文档）。
- `extra`：微博特有信息原文——作者资料 `author`（昵称/uid/认证/粉丝/地区/性别等，公开帖文保留原文）、
  `page`/`rank_in_page`（搜索页位次）、`region_name`（发布地区）、`source`（发布客户端）、
  `topics`（话题）、`pics`/`pic_num`/`video`、`text_html`（原始 HTML 正文）、`is_long_text`、
  `search_card`（搜索结果卡片摘要）、`scraped_at`（抓取落盘 UTC 时间）等。
- 旧交付文件已并入本 JSON：`posts.ndjson`/`topic.json`/`posts.csv` 的全部字段保留在 `documents[].extra` 与通用字段；
  `daily_heat.csv` 并入 `stats.daily_heat`；`comments.csv` 为空表头（本次未爬评论），不再保留。

## 数据口径（重要）

1. **关键词过滤**：每条必须含 ≥1 主题词（佛得角/沃齐尼亚）**且** ≥1 事件词（世界杯/晋级/首秀等），
   且不含排除词（篮球世界杯/电竞世界杯等）——见 `keywords.json`。
2. **统一抽样口径**：真实热度低的日子(≤10 条)全量保留；高密度/溢出日(微博单日 ≥500 封顶)与
   中密度日统一保留每天 **≤30 条**（取当天最新），消除 42→1000 之类的采集断层，每日样本与真实热度同比例。
3. **顶部平台说明**：6-15 起爆发期、7-19~7-26 决赛窗口的每天真实量级不同（探测显示多日 ≥500，7-20 实际抓取处理超 2000 条），
   统一截到 30 条/天后峰谷差被压平；要还原真实量级请看统一 JSON 的 `stats.daily_heat`（含 `total_reference`/`is_overflow`/`final_sample`）。
4. 过滤与抽样规则可在 `keywords.json` / 重跑脚本参数中调整后重新生成。

## 热度形态速览（每日样本数）

```
05-28~06-14: 4~10/天        （低热度，全量）
06-15:       29             （真实爆发起点：该日 ≥500 条）
06-16~07-18: 21~30/天       （抽样）
07-19~07-26: 30/天          （决赛窗口，真实量更高）
```

## 复跑示例

`data/` 只保留统一 JSON，重抓后从新的输出目录重新转换生成即可（无需改动 `data/`）：

```bash
# 1) 抓取(全量滑动窗口): 逐帖落盘到 out/xxx/posts.ndjson
node scraper_batch.js --query 世界杯佛得角 --timescope 2026-05-28:2026-07-26 --comments off \
     --filter --daily-cap 1000 --out out/xxx

# 2) 清洗/降采样: 统一每日≤N 条 + 关键词 + 排序(作用于 out/xxx, 不改 data/)
node clean_data.js --out out/xxx

# 3) 生成统一格式交付 JSON(默认从 data/ 读; 这里从新输出目录读) → data/
node convert_to_unified.js --in out/xxx --out data
```

> 转换脚本内置自检：文档计数与 `daily_heat` 日样本一致、`doc_id` 唯一、
> `published_at` 落在 `collection_window` 内、`content_hash` 与正文一致、每条都命中关键词规则。

> Cookie 说明：`cookies.txt` 为登录凭证（SUB/SUBP），失效时用浏览器 F12 复制请求头 Cookie 整体替换。
> 请勿调小脚本内的请求间隔，风控风险自负。
