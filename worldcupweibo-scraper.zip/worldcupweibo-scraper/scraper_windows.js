#!/usr/bin/env node
/**
 * 滑动时间窗驱动 v2 —— 突破单次搜索 50 页上限，把 [BOTTOM, TOP] 全时段帖子挖尽。
 * ---------------------------------------------------------------------------
 * 背景: s.weibo.com 对同一个 timescope 最多只返回前 50 页(每页约 10 帖，
 *       page>50 会与 page=1 内容循环重复)。若窗口内帖子超过 ~500 条，
 *       更早内容会被截断看不到。
 * v2 要点:
 *  1) 窗口上界 top 支持两种粒度: 日期 'YYYY-MM-DD'(边界=次日0点) 与
 *     小时 'YYYY-MM-DD-HH'(边界=该小时整点, 实测为排他上界)。timescope
 *     混合格式 "2026-05-28:2026-07-25-11" 实测有效。
 *  2) 每窗口跑完取【本次新增帖】的最旧时间 winMin, 用 advance() 把 top
 *     收窄到 winMin 的下一整点/次日。某天帖子超过一窗容量时, 会以小时
 *     粒度逐段消化, 不再漏掉当天的凌晨部分。
 *  3) 跨窗口去重: 所有窗口写同一 out 目录, scraper_batch.js 以 posts.ndjson
 *     的 mid 为 seen 集合(--page-start 让新窗口从第 1 页翻起), 已抓帖只
 *     消耗廉价分页 HTML, 不重复请求详情接口。
 *  4) 断点续跑: 每窗口把下一 top 持久化到 driver_state.json; 中断后原命令
 *     重跑即从上次位置继续(已抓数据天然幂等)。
 *
 * 用法:
 *   node scraper_windows.js --query 世界杯佛得角 --bottom 2026-05-28 --top 2026-07-26 \
 *        --pages 50 --max-win 20 --out out/xxx
 */
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

// ---------------- 参数 ----------------
function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) { a[k.slice(0, eq)] = k.slice(eq + 1); }
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const SCRAPER = path.join(ROOT, "scraper_batch.js");
const QUERY = ARG.query || "世界杯佛得角";
const BOTTOM = ARG.bottom || "2026-05-28";
const TOP0 = ARG.top || "2026-07-26";
const PAGES = parseInt(ARG.pages || "50", 10);
const MAX_WIN = parseInt(ARG["max-win"] || "20", 10);
const WAIT_BLOCK = parseInt(ARG.wait || "300", 10);
const SLEEP_BETWEEN = parseInt(ARG["sleep-between"] || "25", 10);
const FILTER_ON = !ARG["no-filter"];          // 关键词过滤(读 scraper 同目录 keywords.json)
const DAILY_CAP = parseInt(ARG["daily-cap"] || "1000", 10); // 每个自然日最多保留条数(0=不限)
const STOP_AT = ARG["stop-at"] || "";          // 挖到该日期(含)即完成, 用于双开分片: A 挖 [stop_at, TOP], B 挖 [BOTTOM, stop_at-1]
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out)
  : path.join(ROOT, "out", `${QUERY}_slide_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}`);

const NDJSON = path.join(OUT_DIR, "posts.ndjson");
const META = path.join(OUT_DIR, "meta.json");
const STATE = path.join(OUT_DIR, "driver_state.json");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------- 状态 ---------------
/** 读整份 ndjson: count=总行数, gMin=全部详情成功行的最旧 created_at */
function scanAll() {
  let count = 0, gMin = null;
  if (fs.existsSync(NDJSON)) {
    for (const ln of fs.readFileSync(NDJSON, "utf8").split("\n")) {
      if (!ln.trim()) continue;
      try {
        const o = JSON.parse(ln);
        count++;
        const t = o.detail && o.detail.created_at;
        if (t && (!gMin || t < gMin)) gMin = t;
      } catch (e) { /* 坏行忽略 */ }
    }
  }
  return { count, gMin };
}
/** 读本次窗口新增行(第 fromCount 行之后): added=新增行数, winMin=其中详情最旧时间 */
function scanTail(fromCount) {
  let added = 0, winMin = null;
  if (fs.existsSync(NDJSON)) {
    const lines = fs.readFileSync(NDJSON, "utf8").split("\n");
    for (let i = fromCount; i < lines.length; i++) {
      const ln = lines[i];
      if (!ln.trim()) continue;
      try {
        const o = JSON.parse(ln);
        added++;
        const t = o.detail && o.detail.created_at;
        if (t && (!winMin || t < winMin)) winMin = t;
      } catch (e) { /* 坏行忽略 */ }
    }
  }
  return { added, winMin };
}
function readMeta() {
  try { return JSON.parse(fs.readFileSync(META, "utf8")); } catch (e) { return {}; }
}
function readState() {
  try { return JSON.parse(fs.readFileSync(STATE, "utf8")); } catch (e) { return {}; }
}
function writeState(s) { fs.writeFileSync(STATE, JSON.stringify(s, null, 2), "utf8"); }
function isBlocked(stop) {
  return /验证码|风控|两次抓取均无卡片|连续 \d+ 页无卡片|HTML 抓取失败/.test(stop || "");
}
function dateAdd(d, days) {
  const [y, m, dd] = d.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, dd + days)).toISOString().slice(0, 10);
}
const pad = (n) => String(n).padStart(2, "0");
const topKind = (t) => /^\d{4}-\d{2}-\d{2}$/.test(t) ? "day" : "hour";
/** top 边界的绝对分钟数(用于比较与推进), day 型边界=次日0点, hour 型边界=该小时整点 */
function boundaryMin(t) {
  const [y, m, d] = t.slice(0, 10).split("-").map(Number);
  const day0 = Date.UTC(2026, 0, 1);
  const days = Math.round((Date.UTC(y, m - 1, d) - day0) / 86400000);
  return topKind(t) === "day" ? days * 1440 + 1440 : days * 1440 + (+t.slice(11, 13)) * 60;
}
/**
 * 由窗口新增帖最旧时刻 M("YYYY-MM-DD HH:MM:SS") 推算出新 top。
 * 新上界 = M 的下一整点(重叠<1h, 由 seen 去重消化); 23 点时取次日(日期型)。
 */
function advance(top, M) {
  const d = M.slice(0, 10);
  const hh = +M.slice(11, 13);
  // 新上界 = M 的下一整点(重叠<1h 由 seen 消化)。hh=23 时下一整点是次日 0:00,
  // 等价于日期型上界 d(其边界即次日 0:00)。
  let cand = hh === 23 ? d : `${d}-${pad(hh + 1)}`;
  if (boundaryMin(cand) >= boundaryMin(top)) { // 防御: 理论上 M 总在 top 边界内
    console.warn(`[驱动] 推进异常(M=${M} 不在 top=${top} 边界内), top 前移一天。`);
    cand = dateAdd(d, -1);
  }
  return cand;
}

// ---------------- 执行 ----------------
function runScraper(args) {
  const r = spawnSync(process.execPath, [SCRAPER, ...args], { cwd: ROOT, stdio: "inherit" });
  return r.status == null ? -1 : r.status;
}

/** 跑一个窗口(带风控重试, scraper 断点续爬故重跑安全) */
async function runWindow(top) {
  const before = scanAll();
  let attempt = 0;
  while (true) {
    attempt++;
    console.log(`\n======== [窗口] timescope ${BOTTOM}:${top} (第 ${attempt} 次尝试) ========`);
    const filterArgs = FILTER_ON ? ["--filter", "--daily-cap", String(DAILY_CAP)] : [];
    const code = runScraper(["--query", QUERY, "--timescope", `${BOTTOM}:${top}`, "--comments", "off",
      "--pages", String(PAGES), "--out", OUT_DIR, "--page-start", ...filterArgs]);
    const m = readMeta();
    const stop = m.stop_reason || "";
    const tail = scanTail(before.count);
    const all = scanAll();
    if (!isBlocked(stop)) {
      return { added: tail.added, winMin: tail.winMin, gMin: all.gMin, stop, meta: m, code };
    }
    if (attempt >= 3) {
      console.error(`[驱动] 连续 ${attempt} 次风控中止，保留进度并停止。稍后可原命令重跑续爬。`);
      process.exit(2);
    }
    console.log(`[驱动] 检测到风控中止，等待 ${WAIT_BLOCK}s 后重试同一窗口 ...`);
    await sleep(WAIT_BLOCK * 1000);
  }
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  console.log(`========================================`);
  console.log(`滑动窗口驱动 v2 启动`);
  console.log(`  关键词: ${QUERY} | 时间范围 ${BOTTOM} ~ ${TOP0}`);
  console.log(`  每窗口 ${PAGES} 页 | 窗口上限 ${MAX_WIN} | 输出 ${OUT_DIR}`);
  console.log(`========================================`);

  const st0 = readState();
  let top = st0.next_top || TOP0;
  if (topKind(top) === "day" && top < BOTTOM) top = BOTTOM;
  if (st0.next_top) console.log(`[驱动] 从断点续跑: 上次保存 top=${st0.next_top}`);

  let finished = st0.done || false;
  let win = 1;
  for (; win <= MAX_WIN && !finished; win++) {
    writeState({ next_top: top, done: false, updated_at: new Date().toISOString() });
    const r = await runWindow(top);
    const all = scanAll();
    const gMinD = r.gMin ? r.gMin.slice(0, 10) : null;
    const normalEnd = /正常结束/.test(r.stop);
    const ranFull = (r.meta.done_pages || 0) >= PAGES;

    if (normalEnd) { // 窗口提前空页 → [BOTTOM, top] 已无更多内容, 挖尽
      console.log(`[驱动] 窗口空页正常结束，时间窗内容已挖尽。gMin=${r.gMin || "-"} | 累计 ${all.count} 帖`);
      finished = true;
      break;
    }
    if (r.added === 0) { // 0 新增: 该段帖子全部被过滤/已 seen(如某日已达上限)或挖到底
      if (gMinD && gMinD <= BOTTOM) { console.log(`[驱动] 数据已到时间下限 ${BOTTOM}, 完成。`); finished = true; break; }
      const prevTop = top;
      top = dateAdd(top, -1); // 前移一天(过滤导致整段无保留时, 该段不值得再翻)
      if (top <= BOTTOM && top !== BOTTOM) {
        // 已越过下限, 用下限做最后一次收尾或直接完成
        if (gMinD && gMinD <= BOTTOM) { finished = true; break; }
        top = BOTTOM;
      }
      if (top === prevTop) { console.error(`[驱动] 窗口 0 新增且 top 无法推进, 停止。`); break; }
      console.log(`[驱动] 窗口 ${PAGES} 页内 0 新增(全部被过滤/超上限或已处理), top 前移: ${prevTop} → ${top}`);
      if (STOP_AT && top.slice(0, 10) < STOP_AT) {
        console.log(`[驱动] 已越过停止点 ${STOP_AT}，本进程结束（更早区间由另一进程负责）。`);
        finished = true;
        break;
      }
      await sleep(SLEEP_BETWEEN * 1000);
      continue;
    }
    if (!r.winMin) { console.error(`[驱动] 新增帖无有效 created_at(详情全失败), 停止。`); break; }

    console.log(`[驱动] 本次新增 ${r.added} | 累计 ${all.count} | 窗口最旧 ${r.winMin}`);
    const newTop = advance(top, r.winMin);
    if (gMinD && gMinD <= BOTTOM && !ranFull) {
      // 挖到下限当天且窗口未跑满页(正常收尾窗口) → 视为完成
      if (topKind(newTop) === "hour" && newTop.slice(0, 10) === BOTTOM) {
        console.log(`[驱动] 已到时间下限 ${BOTTOM}。`);
        finished = true;
        break;
      }
    }
    top = newTop;
    writeState({ next_top: top, done: false, updated_at: new Date().toISOString() });
    console.log(`[驱动] 下一窗口 top=${top} (窗口 ${win}/${MAX_WIN})`);
    if (STOP_AT && top.slice(0, 10) < STOP_AT) {
      console.log(`[驱动] 已挖过停止点 ${STOP_AT}，本进程结束（更早区间由另一进程负责）。`);
      finished = true;
      break;
    }
    await sleep(SLEEP_BETWEEN * 1000);
  }

  const fin = scanAll();
  if (!finished) console.warn(`[驱动] 达到窗口上限(${MAX_WIN})或异常停止。重跑同命令可从断点继续。`);
  writeState({ next_top: top, done: finished, updated_at: new Date().toISOString(), total: fin.count, g_min: fin.gMin });
  console.log(`\n======== 滑动窗口抓取结束 ========`);
  console.log(`累计 ${fin.count} 帖 | 最旧 ${fin.gMin || "-"} | 目录 ${OUT_DIR}`);
  console.log(`开始最终聚合(build-only) ...`);
  const code = runScraper(["--query", QUERY, "--timescope", `${BOTTOM}:${TOP0}`, "--comments", "off",
    "--build-only", "--out", OUT_DIR]);
  console.log(`聚合完成(退出码 ${code}) → ${OUT_DIR}`);
  process.exit(code === 0 ? 0 : 1);
}

main().catch((e) => { console.error("驱动运行失败:", e); process.exit(1); });
