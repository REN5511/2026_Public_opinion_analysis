#!/usr/bin/env node
/**
 * 按密度比例抽样 —— 依据 density_probe.js 产出的每日总量档案,
 * 为区间内每一天分配"与当天总量成比例"的抓取页数预算, 逐日调用
 * scraper_batch.js(--filter --daily-cap) 抓取, 使最终样本的日分布
 * 近似还原真实热度走势。
 *
 * 预算规则(按天):
 *   - 当天溢出(≥500 条, 微博封顶显示):  抓前 3 页(~30 条, 平台期密度无法更高)
 *   - 当天 <500 条且页数 p>0:            抓 round(p*0.15) 页(≥1)
 *   - 当天总量很小(≤10, p=0 无分页器):  抓 1 页(即全量)
 * 用法:
 *   node sample_by_density.js --probe out/density_probe_*.json --from 2026-05-28 --to 2026-06-30 --out out/xxx
 */
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) a[k.slice(0, eq)] = k.slice(eq + 1);
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const SCRAPER = path.join(ROOT, "scraper_batch.js");
const QUERY = ARG.query || "世界杯佛得角";
const PROBE = path.resolve(ROOT, ARG.probe || "out/density_probe.json");
const FROM = ARG.from || "2026-05-28";
const TO = ARG.to || "2026-07-18";
const RATIO = parseFloat(ARG.ratio || "0.15");   // 非溢出日抓取其页数的比例
const OVERFLOW_PAGES = parseInt(ARG["overflow-pages"] || "3", 10); // 溢出日抓取页数
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out)
  : path.join(ROOT, "out", `${QUERY}_density_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}`);
const NDJSON = path.join(OUT_DIR, "posts.ndjson");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const probe = JSON.parse(fs.readFileSync(PROBE, "utf8"));
const byDay = {};
for (const r of probe) byDay[r.day] = r;

function budgetFor(r) {
  if (r.overflow) return OVERFLOW_PAGES;
  if (!r.pages && r.cards > 0) return 1;              // 无分页器但当天有卡片(≈≤10条)
  if (r.pages <= 0) return 0;                          // 无内容
  return Math.max(1, Math.min(r.pages, Math.round(r.pages * RATIO)));
}
function daysBetween(a, b) {
  const out = [];
  let cur = Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10));
  const end = Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10));
  while (cur <= end) { const x = new Date(cur); out.push(`${x.getUTCFullYear()}-${String(x.getUTCMonth() + 1).padStart(2, "0")}-${String(x.getUTCDate()).padStart(2, "0")}`); cur += 86400000; }
  return out;
}
function scanCount() {
  if (!fs.existsSync(NDJSON)) return 0;
  let n = 0;
  for (const l of fs.readFileSync(NDJSON, "utf8").split("\n")) if (l.trim()) n++;
  return n;
}
function runScraper(args) {
  const r = spawnSync(process.execPath, [SCRAPER, ...args], { cwd: ROOT, stdio: "inherit" });
  return r.status == null ? -1 : r.status;
}

(async () => {
  const days = daysBetween(FROM, TO).filter((d) => byDay[d]);
  fs.mkdirSync(OUT_DIR, { recursive: true });
  console.log(`========================================`);
  console.log(`按密度抽样启动: ${QUERY}`);
  console.log(`  范围 ${FROM}~${TO} | ${days.length} 天 | 输出 ${OUT_DIR}`);
  const plan = days.map((d) => ({ day: d, r: byDay[d], pages: budgetFor(byDay[d]) }));
  const planSum = plan.reduce((s, x) => s + x.pages, 0);
  console.log(`  预算总页数 ${planSum} (≈${planSum * 10} 条详情请求)`);
  console.log(`  溢出(≥500)日 ${plan.filter((x) => x.r.overflow).length} 天 × ${OVERFLOW_PAGES}页; 非溢出按 ${RATIO * 100}%`);
  console.log(`========================================`);

  let failStreak = 0;
  for (let i = 0; i < days.length; i++) {
    const d = days[i];
    const p = budgetFor(byDay[d]);
    if (p <= 0) { console.log(`  ${d}: 无内容, 跳过`); continue; }
    const before = scanCount();
    console.log(`\n[${i + 1}/${days.length}] ${d}: 总量${byDay[d].total}${byDay[d].overflow ? "(溢出≥500)" : ""} → 抓 ${p} 页`);
    let code = runScraper(["--query", QUERY, "--timescope", `${d}:${d}`, "--pages", String(p),
      "--comments", "off", "--filter", "--daily-cap", "1000", "--page-start", "--out", OUT_DIR]);
    if (code !== 0) {
      failStreak++;
      console.log(`  [密度抽样] 退出码 ${code}, 等待 120s 重试 (连续失败 ${failStreak}) ...`);
      await sleep(120000);
      code = runScraper(["--query", QUERY, "--timescope", `${d}:${d}`, "--pages", String(p),
        "--comments", "off", "--filter", "--daily-cap", "1000", "--page-start", "--out", OUT_DIR]);
    } else failStreak = 0;
    const after = scanCount();
    console.log(`  ${d} 完成: 累计 ${after} 行 (本天新增 ${after - before})`);
    await sleep(8000);
    if (failStreak >= 3) { console.error("连续失败过多, 停止(保留进度)。"); break; }
  }
  console.log(`\n======== 按密度抽样结束 ========`);
  console.log(`累计 ${scanCount()} 行 → ${OUT_DIR}`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
