#!/usr/bin/env node
/**
 * 抽样抓取驱动 —— 按时间均匀取 N 个采样点，每点只翻前 K 页，快速覆盖 [BOTTOM, TOP]。
 * 用途: 不追求挖穿每个爆发日(那需要数小时)，而是让样本散布在整个时间范围内，
 *       配合 scraper_batch.js 的关键词过滤与每日上限，快速凑够配额。
 *
 * 原理: 对第 i 个采样点(日期 pt)，调用
 *   scraper_batch --timescope BOTTOM:pt --pages K --filter --daily-cap C --page-start
 * 搜索按时间倒序返回，前 K 页即 pt 当天(或最近)的内容；采样点在时间轴上均匀分布，
 * 覆盖就均匀。所有采样点写同一 out 目录，scraper 以 ndjson 的 mid 集合跨点去重。
 *
 * 用法:
 *   node sample_windows.js --bottom 2026-05-28 --top 2026-07-18 --points 9 \
 *        --pages 8 --out out/xxx
 */
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) a[k.slice(0, eq)] = k.slice(eq + 1);
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const SCRAPER = path.join(ROOT, "scraper_batch.js");
const QUERY = ARG.query || "世界杯佛得角";
const BOTTOM = ARG.bottom || "2026-05-28";
const TOP = ARG.top || "2026-07-18";
const POINTS = parseInt(ARG.points || "9", 10);
const PAGES = parseInt(ARG.pages || "8", 10);
const DAILY_CAP = parseInt(ARG["daily-cap"] || "1000", 10);
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out)
  : path.join(ROOT, "out", `${QUERY}_sample_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}`);
const NDJSON = path.join(OUT_DIR, "posts.ndjson");
const META = path.join(OUT_DIR, "meta.json");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function dateRange(fromStr, toStr) {
  const out = [];
  let cur = Date.UTC(+fromStr.slice(0, 4), +fromStr.slice(5, 7) - 1, +fromStr.slice(8, 10));
  const end = Date.UTC(+toStr.slice(0, 4), +toStr.slice(5, 7) - 1, +toStr.slice(8, 10));
  while (cur <= end) { const x = new Date(cur); out.push(`${x.getUTCFullYear()}-${String(x.getUTCMonth() + 1).padStart(2, "0")}-${String(x.getUTCDate()).padStart(2, "0")}`); cur += 86400000; }
  return out;
}
/** 在日期轴上均匀取 POINTS 个采样点(靠近 TOP 端, 与抓取方向一致) */
function pickPoints() {
  const days = dateRange(BOTTOM, TOP);
  const out = [];
  for (let i = 0; i < POINTS; i++) {
    const idx = Math.min(days.length - 1, Math.round((days.length - 1) * (1 - i / POINTS))); // 新→旧
    out.push(days[idx]);
  }
  return out;
}
function scanCount() {
  if (!fs.existsSync(NDJSON)) return 0;
  let n = 0;
  for (const l of fs.readFileSync(NDJSON, "utf8").split("\n")) if (l.trim()) n++;
  return n;
}
function runScraper(args) {
  const r = spawnSync(process.execPath, [SCRAPER, ...args], { cwd: ROOT, stdio: "inherit" });
  return r.status == null ? -1 : r.status;
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const pts = pickPoints();
  console.log(`========================================`);
  console.log(`抽样抓取启动: ${QUERY}`);
  console.log(`  范围 ${BOTTOM}~${TOP} | ${POINTS} 个采样点 | 每点 ${PAGES} 页`);
  console.log(`  输出 ${OUT_DIR}`);
  console.log(`  采样点: ${pts.join(", ")}`);
  console.log(`========================================`);

  for (let i = 0; i < pts.length; i++) {
    const pt = pts[i];
    const before = scanCount();
    console.log(`\n[采样 ${i + 1}/${pts.length}] timescope ${BOTTOM}:${pt}`);
    let code = runScraper(["--query", QUERY, "--timescope", `${BOTTOM}:${pt}`, "--pages", String(PAGES),
      "--comments", "off", "--filter", "--daily-cap", String(DAILY_CAP), "--page-start", "--out", OUT_DIR]);
    if (code !== 0) {
      console.log(`[抽样] 该点退出码 ${code}，等待 120s 重试一次 ...`);
      await sleep(120000);
      code = runScraper(["--query", QUERY, "--timescope", `${BOTTOM}:${pt}`, "--pages", String(PAGES),
        "--comments", "off", "--filter", "--daily-cap", String(DAILY_CAP), "--page-start", "--out", OUT_DIR]);
    }
    const after = scanCount();
    console.log(`[采样 ${i + 1}] 完成: 累计 ${after} 行 (本点新增 ${after - before})`);
    await sleep(15000); // 采样点之间缓和
  }

  console.log(`\n======== 抽样抓取结束 ========`);
  console.log(`累计 ${scanCount()} 行 → ${OUT_DIR}`);
  process.exit(0);
}

main().catch((e) => { console.error("抽样运行失败:", e); process.exit(1); });
