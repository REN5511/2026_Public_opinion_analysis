#!/usr/bin/env node
/**
 * 微博搜索批量爬虫 —— 自动翻页抓取帖子 + 每帖全量可见评论
 * 结构分级: 话题(topic) -> 帖子(post, 含 page/rank) -> 评论(comment)
 *
 * 用法:
 *   node scraper_batch.js --query 世界杯佛得角 --pages 50
 *   node scraper_batch.js --query 世界杯佛得角 --pages 50 --comments top10   # 每帖只取赞数最高10条
 *   node scraper_batch.js --build-only --out <目录>                            # 只把已有 ndjson 聚合输出
 *
 * 特性: 每处理完一帖立即落盘 posts.ndjson(断点安全) / 重跑同一 --out 自动续爬 /
 *       单帖失败跳过 / 风控检测: 连续失败自动长暂停, 严重则停止并提示续跑
 */
const fs = require("fs");
const path = require("path");

// ---------------- 参数 ----------------
function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) { a[k.slice(0, eq)] = k.slice(eq + 1); }
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const ROOT = __dirname;
const QUERY = ARG.query || "世界杯佛得角";
const PAGES = parseInt(ARG.pages || "50", 10);
const COMMENT_MODE = ARG.comments || "all"; // all | top10 | off
const TOP_N = parseInt(ARG.topN || "10", 10);
const COOKIE_FILE = ARG.cookie ? path.resolve(ROOT, ARG.cookie) : path.join(ROOT, "cookies.txt");
const BUILD_ONLY = !!ARG["build-only"];
const OUT_DIR = ARG.out ? path.resolve(ROOT, ARG.out)
  : path.join(ROOT, "out", `${QUERY}_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}`);

// ---------------- 常量 ----------------
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const FROM = ARG.from || "";
const TO = ARG.to || "";
const TIMESCOPE = ARG.timescope || (FROM && TO ? `${FROM}:${TO}` : "");
const SPLIT_DAYS = !!ARG["split-days"]; // 按天切分抓取（每天独立 timescope，保证不被热点日霸榜截断）
const DAILY_PAGES = parseInt(ARG["day-pages"] || "50", 10);
function makeSearchNoPage(ts) {
  let b = `https://s.weibo.com/weibo?q=${encodeURIComponent(QUERY)}&typeall=1&suball=1&Refer=g`;
  if (ts) b += `&timescope=${encodeURIComponent("custom:" + ts)}`;
  return b;
}
let SEARCH_NO_PAGE = makeSearchNoPage(TIMESCOPE);
const SEARCH_BASE = SEARCH_NO_PAGE + "&page=";
// 日期序列（含首尾）
function dateRange(fromStr, toStr) {
  const out = [];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fromStr) || !/^\d{4}-\d{2}-\d{2}$/.test(toStr)) return out;
  let cur = Date.UTC(+fromStr.slice(0, 4), +fromStr.slice(5, 7) - 1, +fromStr.slice(8, 10));
  const end = Date.UTC(+toStr.slice(0, 4), +toStr.slice(5, 7) - 1, +toStr.slice(8, 10));
  const DAY = 86400000;
  while (cur <= end) { const x = new Date(cur); out.push(`${x.getUTCFullYear()}-${String(x.getUTCMonth() + 1).padStart(2, "0")}-${String(x.getUTCDate()).padStart(2, "0")}`); cur += DAY; }
  return out;
}
const DAYS = SPLIT_DAYS ? dateRange(FROM, TO) : [];
const COOKIE = (() => {
  if (!fs.existsSync(COOKIE_FILE)) { console.error(`找不到 cookie 文件: ${COOKIE_FILE}`); process.exit(1); }
  return fs.readFileSync(COOKIE_FILE, "utf8").trim();
})();

// ---------------- 关键词过滤 / 每日上限 ----------------
// 规则文件 keywords.json: { subject:[...], event:[...], exclude:[...] }
// 启用: --filter(需 keywords.json 存在); 每日保留上限: --daily-cap N (0=不限)
const KEYWORDS_FILE = path.join(ROOT, "keywords.json");
const KEYWORDS = (() => { try { return JSON.parse(fs.readFileSync(KEYWORDS_FILE, "utf8")); } catch (e) { return null; } })();
const FILTER = !!ARG.filter && !!KEYWORDS;
const DAILY_CAP = parseInt(ARG["daily-cap"] || "0", 10);
if (ARG.filter && !KEYWORDS) console.warn(`[提示] --filter 已指定但找不到 ${KEYWORDS_FILE}，将不做关键词过滤。`);
if (FILTER) console.log(`[提示] 关键词过滤已启用: 需含主题词+事件词且不含排除词 (keywords.json)`);
if (DAILY_CAP > 0) console.log(`[提示] 每日上限已启用: 每个自然日最多保留 ${DAILY_CAP} 条`);
const dayCount = new Map(); // "YYYY-MM-DD" -> 已保留条数(从 ndjson 恢复 + 运行中累计)

/** 判断帖子是否保留: 过关键词(可选) + 未超当日上限(可选)。通过时内部累加 dayCount。 */
function shouldKeep(detail) {
  const text = ((detail.text || "") + " " + (detail.topics || []).join(" ")).toLowerCase();
  if (FILTER) {
    if (KEYWORDS.exclude && KEYWORDS.exclude.length && KEYWORDS.exclude.some((w) => text.includes(String(w).toLowerCase())))
      return { keep: false, reason: "命中排除词(如 篮球世界杯/电竞世界杯)" };
    if (KEYWORDS.subject && KEYWORDS.subject.length && !KEYWORDS.subject.some((w) => text.includes(String(w).toLowerCase())))
      return { keep: false, reason: "不含主题词(佛得角/沃齐尼亚)" };
    if (KEYWORDS.event && KEYWORDS.event.length && !KEYWORDS.event.some((w) => text.includes(String(w).toLowerCase())))
      return { keep: false, reason: "不含事件词(世界杯/晋级/首秀等)" };
  }
  if (DAILY_CAP > 0) {
    const day = (detail.created_at || "").slice(0, 10);
    if (day) {
      const c = dayCount.get(day) || 0;
      if (c >= DAILY_CAP) return { keep: false, reason: `单日已达上限 ${DAILY_CAP}` };
      dayCount.set(day, c + 1);
    }
  }
  return { keep: true };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const jitter = (min, max) => min + Math.random() * (max - min);

// ---------------- 工具 ----------------
function strip(s) {
  if (!s) return "";
  return String(s)
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<a[^>]*href="\/n\/([^"]*)"[^>]*>@?([^<]*)<\/a>/gi, "@$1")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/展开c/g, "").replace(/全文/g, "")
    .replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}
const MONTHS = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
function fmtTime(s) {
  if (!s) return "";
  const m = /^\w{3} (\w{3}) (\d{2}) (\d{2}):(\d{2}):(\d{2}) [+-]\d{4} (\d{4})$/.exec(s.trim());
  if (!m) return strip(s);
  return `${m[6]}-${String(MONTHS[m[1]]).padStart(2, "0")}-${m[2]} ${m[3]}:${m[4]}:${m[5]}`;
}
function parseNum(s) {
  if (s == null) return null;
  const t = String(s).replace(/,/g, "").trim();
  const m = /^([\d.]+)\s*(亿|万)?$/.exec(t);
  if (!m) return null;
  const n = parseFloat(m[1]);
  return m[2] === "万" ? Math.round(n * 10000) : m[2] === "亿" ? Math.round(n * 1e8) : Math.round(n);
}
function esc(v) { const s = String(v ?? ""); return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
function writeCsv(file, headers, rows) {
  fs.writeFileSync(file, "\ufeff" + [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join("\r\n"), "utf8");
}

// ---------------- 网络请求(带重试/风控) ----------------
let consecutiveApiFail = 0;
const STALLED = { halted: false, reason: "" };
async function backoffIfNeeded() {
  if (consecutiveApiFail >= 10 && !STALLED.halted) {
    console.log(`  [风控] 连续 ${consecutiveApiFail} 次接口失败，暂停 120s ...`);
    await sleep(120000);
    consecutiveApiFail = 0;
  }
  if (STALLED.halted) { console.error(`  已因风控停止: ${STALLED.reason}`); process.exit(1); }
}
async function getJson(url, uid, retries = 2) {
  for (let i = 0; i <= retries; i++) {
    await backoffIfNeeded();
    try {
      const res = await fetch(url, { headers: { "User-Agent": UA, Referer: `https://weibo.com/${uid}`, Accept: "application/json, text/plain, */*", "X-Requested-With": "XMLHttpRequest", "Accept-Language": "zh-CN,zh;q=0.9", Cookie: COOKIE } });
      const j = await res.json();
      if (j.ok === 1) { consecutiveApiFail = 0; return j; }
      if (i < retries) { await sleep(jitter(2000, 4000)); continue; }
      consecutiveApiFail++;
      return j;
    } catch (e) {
      if (i < retries) { await sleep(jitter(2000, 4000)); continue; }
      consecutiveApiFail++;
      return { ok: -1, msg: String(e.message || e) };
    }
  }
}
async function getHtml(url, referer, retries = 2) {
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": UA, Referer: referer || SEARCH_NO_PAGE, Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9", Cookie: COOKIE } });
      if (res.status !== 200) { if (i < retries) { await sleep(jitter(4000, 7000)); continue; } return null; }
      return await res.text();
    } catch (e) {
      if (i < retries) { await sleep(jitter(4000, 7000)); continue; }
      return null;
    }
  }
}

// ---------------- 解析搜索页卡片 ----------------
function parseCards(html) {
  const cards = [];
  const re = /<div class="card-wrap" action-type="feed_list_item" mid="(\d+)"[\s\S]*?<!--\/card-wrap-->/g;
  let m;
  while ((m = re.exec(html))) {
    const seg = m[0];
    const mid = m[1];
    const uidM = /href="\/\/weibo\.com\/(\d+)\?refer_flag/.exec(seg);
    const nickM = /class="name"[^>]*nick-name="([^"]+)"/.exec(seg) || /class="name"[^>]*>([^<]+)</.exec(seg);
    const verTitleM = /woo-avatar-icon">\s*<span[^>]*title="([^"]*)"/.exec(seg);
    const vipM = /user_vip_icon_container[\s\S]{0,160}?vip_(\d+)\.png/.exec(seg);
    const fromM = /<div class="from"[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/.exec(seg);
    const txtFull = /node-type="feed_list_content_full"[^>]*>([\s\S]*?)<\/p>/.exec(seg);
    const txtCut = /node-type="feed_list_content"[^>]*>([\s\S]*?)<\/p>/.exec(seg);
    const num = (at) => {
      const r = new RegExp(`action-type="${at}"[\\s\\S]*?<\\/span>\\s*([\\d.,亿万]+)</a>`).exec(seg);
      return r ? { display: r[1], value: parseNum(r[1]) } : { display: "", value: null };
    };
    const likeM = /woo-like-count">([\d.,亿万]+)<\/span>/.exec(seg);
    cards.push({
      mid, uid: uidM ? uidM[1] : "", nick: nickM ? nickM[1] : "",
      rank_in_page: cards.length + 1,
      verified_title: verTitleM ? verTitleM[1] : "", vip_level: vipM ? parseInt(vipM[1], 10) : null,
      time_display: fromM ? strip(fromM[1]) : "",
      text: strip((txtFull ? txtFull[1] : txtCut ? txtCut[1] : "").replace(/^展开c/, "")),
      page_转: num("feed_list_forward"), page_评: num("feed_list_comment"),
      page_赞: likeM ? { display: likeM[1], value: parseNum(likeM[1]) } : { display: "", value: null },
    });
  }
  return cards;
}

// ---------------- 帖子详情 / 评论 ----------------
function pickUser(u, extra) {
  if (!u) return null;
  const b = {
    uid: String(u.id ?? u.idstr ?? ""), screen_name: u.screen_name ?? "",
    profile_url: u.profile_url ? (u.profile_url.startsWith("http") ? u.profile_url : "https://weibo.com" + u.profile_url) : "",
    avatar_large: u.avatar_large ?? u.profile_image_url ?? "",
    verified: !!u.verified, verified_type: u.verified_type ?? null,
    mbrank: u.mbrank ?? 0, mbtype: u.mbtype ?? 0,
    following: !!u.following, follow_me: !!u.follow_me,
    followers_count: u.followers_count ?? null, friends_count: u.friends_count ?? null, statuses_count: u.statuses_count ?? null,
    location: u.location ?? "", gender: u.gender ?? "", description: u.description ?? "",
  };
  return extra ? { ...b, ...extra } : b;
}
function pickComment(c) {
  return {
    comment_id: String(c.id ?? ""), rootid: String(c.rootid ?? c.id ?? ""), mid: String(c.mid ?? ""),
    floor_number: c.floor_number ?? null,
    user: pickUser(c.user),
    created_at: fmtTime(c.created_at), source: strip(c.source),
    like_counts: c.like_counts ?? 0, liked: !!c.liked,
    disable_reply: !!c.disable_reply, reply_total: (c.total_number ?? 0),
    reply_first_page: Array.isArray(c.comments) ? c.comments.slice(0, 10).map(pickComment) : [],
    text: strip(c.text_raw || c.text), text_html: c.text ?? "",
    url: `https://weibo.com/comment/show?rl_type=1&mid=${c.mid || ""}&cid=${c.id}`,
  };
}
async function fetchPostDetail(card) {
  const s = await getJson(`https://weibo.com/ajax/statuses/show?id=${card.mid}`, card.uid);
  if (s.ok !== 1) return { error: s.msg || `show ok=${s.ok}` };
  const d = {
    mid: String(s.mid ?? card.mid), mblogid: s.mblogid ?? "",
    url: s.user ? `https://weibo.com/${s.user.id}/${s.mblogid || s.mid}` : "",
    user: pickUser(s.user),
    created_at: fmtTime(s.created_at), created_at_display: card.time_display,
    source: strip(s.source), region_name: s.region_name ?? "",
    isLongText: !!s.isLongText, text: strip(s.text_raw || s.text || card.text), text_html: s.text ?? "",
    reposts_count: s.reposts_count ?? card.page_转.value, comments_count: s.comments_count ?? card.page_评.value,
    attitudes_count: s.attitudes_count ?? card.page_赞.value,
    page_display: { 转发: card.page_转.display, 评论: card.page_评.display, 赞: card.page_赞.display },
    pics: (s.pic_ids || []).map((p) => `https://wx4.sinaimg.cn/large/${p}.jpg`), pic_num: s.pic_num ?? 0,
    video: s.page_info && (s.page_info.media_info || s.page_info.type === "video")
      ? { type: s.page_info.type, title: (s.page_info.page_title || s.page_info.media_info?.title || ""), cover: s.page_info.page_pic?.url || "" } : null,
    topics: (s.topic_struct || []).map((t) => t.topic_title || t.title).filter(Boolean),
  };
  if (d.isLongText) {
    const lt = await getJson(`https://weibo.com/ajax/statuses/longtext?id=${card.mid}`, card.uid);
    if (lt.ok === 1 && lt.data) { d.text = strip(lt.data.longTextContent || lt.data.text || d.text); d.long_text_html = lt.data.longTextContent ?? ""; }
    await sleep(jitter(1300, 2200));
  }
  return d;
}
async function fetchAllComments(card) {
  let all = [], max_id = "", page = 0, annotated = null, err = "";
  const base = `https://weibo.com/ajax/statuses/buildComments?flow=1&is_reload=1&id=${card.mid}&is_show_bulletin=2&is_mix=0&count=20`;
  do {
    const j = await getJson(`${base}${max_id ? "&max_id=" + max_id : ""}`, card.uid);
    if (j.ok !== 1 || !Array.isArray(j.data)) { err = j.msg || `评论接口 ok=${j.ok}`; break; }
    if (annotated == null) annotated = j.total_number ?? null;
    all = all.concat(j.data);
    max_id = j.max_id;
    page++;
    if (max_id) await sleep(jitter(1300, 2200));
  } while (max_id && page < 30);
  let list = all.map(pickComment);
  if (COMMENT_MODE === "top10") list = list.sort((a, b) => b.like_counts - a.like_counts || a.floor_number - b.floor_number).slice(0, TOP_N);
  return { annotated, visible: all.length, partial: !!err && all.length > 0, error: err, list };
}

// ---------------- 落盘与状态 ----------------
const NDJSON = path.join(OUT_DIR, "posts.ndjson");
const META = path.join(OUT_DIR, "meta.json");
function loadState() {
  const seen = new Set();
  let donePages = 0;
  dayCount.clear();
  if (fs.existsSync(NDJSON)) {
    const lines = fs.readFileSync(NDJSON, "utf8").split("\n");
    for (const ln of lines) {
      if (!ln.trim()) continue;
      try {
        const o = JSON.parse(ln);
        seen.add(o.mid);
        if (o.page > donePages) donePages = o.page;
        const t = o.detail && o.detail.created_at;
        if (t) { const d = t.slice(0, 10); dayCount.set(d, (dayCount.get(d) || 0) + 1); }
      } catch (e) { /* 忽略坏行 */ }
    }
  }
  let prev = null;
  if (fs.existsSync(META)) { try { prev = JSON.parse(fs.readFileSync(META, "utf8")); } catch (e) {} }
  return { seen, donePages, prev };
}
function saveMeta(extra) {
  const meta = { query: QUERY, timescope: TIMESCOPE || null, comment_mode: COMMENT_MODE, top_n: TOP_N, pages_target: PAGES, output_dir: OUT_DIR, updated_at: new Date().toISOString().slice(0, 19).replace("T", " "), ...extra };
  fs.writeFileSync(META, JSON.stringify(meta, null, 2), "utf8");
}
const ndjsonStream = { fd: null };
function appendPost(row) {
  if (!ndjsonStream.fd) ndjsonStream.fd = fs.openSync(NDJSON, "a");
  fs.writeSync(ndjsonStream.fd, JSON.stringify(row) + "\n");
}

// ---------------- 主流程 ----------------
// ---------------- 按天切分抓取 ----------------
// 微博搜索即使指定 timescope 也按相关度排序、只返回前若干页，热点日期会霸榜截断；
// 按天拆成独立时间窗逐天翻页，可确保区间内每天的内容都被取到（断点续跑按 last_day_done 推进）。
async function crawlSplit() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const { seen, prev } = loadState();
  const cmtLabel = COMMENT_MODE === "all" ? "全部可见" : COMMENT_MODE === "off" ? "关闭(不抓评论)" : "top" + TOP_N;
  console.log(`按天抓取: ${DAYS.length} 天 (${FROM} ~ ${TO}) | 每天上限 ${DAILY_PAGES} 页 | 评论: ${cmtLabel}`);
  console.log(`输出目录: ${OUT_DIR}`);
  let lastDayDone = prev?.last_day_done || "";
  console.log(`续跑: 已处理 ${seen.size} 帖${lastDayDone ? `，最后完成日期 ${lastDayDone}` : ""}\n`);

  let processed = 0, commentsTotal = 0, errors = 0, aborted = "", dropped = 0;
  let startIdx = 0;
  if (lastDayDone) { const i = DAYS.indexOf(lastDayDone); if (i >= 0) startIdx = i + 1; }

  for (let si = startIdx; si < DAYS.length; si++) {
    const day = DAYS[si];
    const base = makeSearchNoPage(`${day}:${day}`) + "&page=";
    let dupStreak = 0, dayNew = 0, dayDone = false;
    for (let page = 1; page <= DAILY_PAGES; page++) {
      const url = base + page;
      console.log(`[${day} 页 ${page}/${DAILY_PAGES}] ${url}`);
      const html = await getHtml(url, page > 1 ? base + (page - 1) : base + 1);
      if (!html) {
        console.error(`  中止: [${day}] 第 ${page} 页 HTML 抓取失败(疑似风控)`);
        aborted = "HTML 抓取失败"; break;
      }
      if (/验证码|请输入验证码|访问过于频繁/.test(html)) {
        console.error(`  中止: [${day}] 触发验证码`);
        aborted = "触发验证码"; break;
      }
      let cards = parseCards(html);
      if (!cards.length) {
        if (/抱歉|未找到|暂时没有相关|没有更多/.test(html)) { console.log(`  [${day}] 无结果，结束该天`); dayDone = true; break; }
        console.log(`  [${day}] 0 张卡片，稍后重试一次`); await sleep(jitter(6000, 9000));
        const h2 = await getHtml(url, base + (page > 1 ? page - 1 : 1));
        const c2 = h2 ? parseCards(h2) : [];
        if (!c2.length) { console.log(`  [${day}] 两次抓取均无卡片，按当日无内容结束`); dayDone = true; break; }
        cards = c2;
      }
      const fresh = cards.filter((c) => !seen.has(c.mid));
      if (cards.length && !fresh.length) {
        dupStreak++;
        if (dupStreak >= 2) { console.log(`  [${day}] 连续 2 页均为重复帖，该天内容已抓完`); dayDone = true; break; }
        console.log(`  [${day}] 本页 ${cards.length} 帖均已处理（重复 ${dupStreak}/2）`);
        continue;
      }
      dupStreak = 0;
      console.log(`  [${day}] 本页 ${cards.length} 帖（新 ${fresh.length} 帖）`);
      let pageErr = 0, pageDrop = 0;
      for (const card of fresh) {
        await sleep(jitter(1300, 2300));
        const detail = await fetchPostDetail(card);
        if (detail.error) {
          errors++; pageErr++;
          console.log(`    @${card.nick} mid=${card.mid}: 详情失败(${detail.error})，跳过`);
          appendPost({ mid: card.mid, page, rank: card.rank_in_page ?? 0, day, card, detail: null, comments: null, error: detail.error, ts: new Date().toISOString() });
          seen.add(card.mid);
          continue;
        }
        // 关键词过滤 + 每日上限（未通过则不抓评论、不落盘）
        const keep = shouldKeep(detail);
        if (!keep.keep) {
          dropped++; pageDrop++;
          seen.add(card.mid);
          if (pageDrop === 1 || pageDrop % 50 === 0) console.log(`    丢弃 @${card.nick} mid=${card.mid} ${(detail.created_at || "").slice(0, 16)} (${keep.reason})`);
          continue;
        }
        let comments = null;
        if (COMMENT_MODE !== "off") {
          await sleep(jitter(1300, 2300));
          comments = await fetchAllComments(card);
          commentsTotal += comments.list.length;
          if (comments.error) { errors++; console.log(`    @${card.nick}: 评论部分失败(${comments.error})，保留 ${comments.list.length} 条`); }
        } else { comments = { mode: "off" }; }
        appendPost({ mid: card.mid, page, rank: card.rank_in_page ?? 0, day, card, detail, comments, error: "", ts: new Date().toISOString() });
        seen.add(card.mid); processed++; dayNew++;
        if (processed % 10 === 0 || processed === 1) console.log(`    进度: 累计已处理 ${processed} 帖`);
      }
      console.log(`  [${day} 页${page}] 完成: 保留 ${fresh.length - pageDrop} / 丢弃 ${pageDrop} 帖`);
      await sleep(jitter(2500, 4000));
      if (dayDone) break;
    }
    const stopNow = !dayDone && pageLimitReached;
    // 记录当天进度（无论自然结束或中断，均标记以便续跑）
    if (dayDone || true) {
      saveMeta({ done_pages: 0, posts_processed: processed, comments_total: commentsTotal, dropped, last_day_done: day, stop_reason: dayDone ? "该天结束(正常/中断)" : "达页上限" });
      console.log(`✔ ${day} 处理结束: 本日新增 ${dayNew} 帖(保留 ${processed} / 丢弃 ${dropped})，共 ${seen.size} 唯一帖\n`);
    }
    // 若因风控中断则整批停止（数据已落盘）
    const hLast = null;
  }

  if (ndjsonStream.fd) fs.closeSync(ndjsonStream.fd);
  saveMeta({ posts_processed: processed, comments_total: commentsTotal, dropped, last_day_done: DAYS[DAYS.length - 1], stop_reason: "完成全部日期" });
  console.log(`\n按天抓取结束: ${DAYS.length} 天, 共 ${seen.size} 唯一帖(保留 ${processed} / 丢弃 ${dropped}), 评论 ${commentsTotal} 条 → ${NDJSON}`);
  return { seen, commentsTotal };
}

async function crawl() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const { seen, donePages, prev } = loadState();
  const cmtLabel = COMMENT_MODE === "all" ? "全部可见" : COMMENT_MODE === "off" ? "关闭(不抓评论)" : "top" + TOP_N;
  console.log(`话题: ${QUERY} | 时间范围: ${TIMESCOPE || "(不限)"} | 目标页数: ${PAGES} | 评论模式: ${cmtLabel}`);
  console.log(`输出目录: ${OUT_DIR}`);
  console.log(`续跑: 已处理 ${seen.size} 帖, 已完成到第 ${donePages} 页${ARG["page-start"] ? "（窗口模式: 从第 1 页开始，跨窗口按 mid 去重）" : ""}\n`);

  let stopReason = prev?.stop_reason || "";
  let processed = 0, commentsTotal = 0, errors = 0, emptyPages = 0, consecutiveEmpty = 0, lastPage = donePages;
  let dropped = 0;

  // --page-start: 窗口滑动模式(由 scraper_windows.js 使用)。
  // 每个新 timescope 窗口都从第 1 页开始翻，但 seen 集合仍来自本目录
  // posts.ndjson(跨窗口按 mid 去重，已抓帖不重复请求详情接口)。
  const START_PAGE = ARG["page-start"] ? 1 : Math.max(1, donePages + 1);
  for (let page = START_PAGE; page <= PAGES; page++) {
    const url = SEARCH_BASE + page;
    console.log(`[页 ${page}/${PAGES}] 抓取 ${url}`);
    const html = await getHtml(url, page > 1 ? SEARCH_BASE + (page - 1) : SEARCH_BASE + 1);
    if (!html) {
      stopReason = `第 ${page} 页 HTML 抓取失败（可能触发风控/网络）`;
      console.error(`  中止: ${stopReason}`); break;
    }
    if (/验证码|请输入验证码|访问过于频繁/.test(html)) {
      stopReason = `第 ${page} 页返回验证码，需人工处理（更新 cookie 或稍后重跑续爬）`;
      console.error(`  中止: ${stopReason}`); break;
    }
    const cards = parseCards(html);
    if (!cards.length) {
      // 区分“真实无结果”与异常
      if (/抱歉|未找到|暂时没有相关|没有更多/.test(html)) { stopReason = `第 ${page} 页无更多结果，正常结束`; console.log(`  ${stopReason}`); break; }
      emptyPages++; consecutiveEmpty++;
      if (consecutiveEmpty >= 3) { stopReason = `连续 ${consecutiveEmpty} 页无卡片，疑似被风控拦截`; console.error(`  中止: ${stopReason}`); break; }
      console.log(`  本页 0 张卡片（第${consecutiveEmpty}次），稍后重试一次`); await sleep(jitter(6000, 9000));
      const html2 = await getHtml(url, SEARCH_BASE + (page > 1 ? page - 1 : 1));
      const cards2 = html2 ? parseCards(html2) : [];
      if (!cards2.length) {
        if (html2 && /抱歉|未找到|暂时没有相关|没有更多/.test(html2)) { stopReason = `第 ${page} 页无更多结果，正常结束`; console.log(`  ${stopReason}`); break; }
        stopReason = `第 ${page} 页两次抓取均无卡片（疑似风控），已保留前 ${seen.size} 帖数据`;
        console.error(`  中止: ${stopReason}`); break;
      }
      cards.push(...cards2);
    } else { emptyPages = 0; consecutiveEmpty = 0; }

    // 去重（跨页可能有重复推送）
    const fresh = cards.filter((c) => !seen.has(c.mid));
    if (cards.length && !fresh.length) {
      console.log(`  本页 ${cards.length} 张均为已处理帖子，跳过详情抓取`);
      saveMeta({ done_pages: page, stop_reason: "" });
      continue;
    }
    console.log(`  本页 ${cards.length} 帖（新 ${fresh.length} 帖）`);

    let pageComments = 0, pageErr = 0, pageDrop = 0;
    for (const card of fresh) {
      // 1) 详情
      await sleep(jitter(1300, 2300));
      const detail = await fetchPostDetail(card);
      let comments = null;
      if (detail.error) {
        errors++; pageErr++;
        console.log(`    @${card.nick} mid=${card.mid}: 详情失败(${detail.error})，跳过该帖`);
        appendPost({ mid: card.mid, page, rank: card._i, card, detail: null, comments: null, error: detail.error, ts: new Date().toISOString() });
        seen.add(card.mid);
        continue;
      }
      // 1.5) 关键词过滤 + 每日上限（未通过则不抓评论、不落盘）
      const keep = shouldKeep(detail);
      if (!keep.keep) {
        dropped++; pageDrop++;
        seen.add(card.mid);
        if (pageDrop === 1 || pageDrop % 50 === 0) console.log(`    丢弃 @${card.nick} mid=${card.mid} ${(detail.created_at || "").slice(0, 16)} (${keep.reason})`);
        continue;
      }
      // 2) 评论（--comments off 时跳过）
      const NO_CMT = COMMENT_MODE === "off";
      if (!NO_CMT) {
        await sleep(jitter(1300, 2300));
        comments = await fetchAllComments(card);
        commentsTotal += comments.list.length;
        pageComments += comments.list.length;
        if (comments.error) { errors++; console.log(`    @${card.nick}: 评论部分失败(${comments.error})，保留已抓 ${comments.list.length} 条`); }
      } else {
        comments = { mode: "off" };
      }
      appendPost({ mid: card.mid, page, card, detail, comments, error: "", ts: new Date().toISOString() });
      seen.add(card.mid);
      processed++;
      if (processed % 10 === 0 || processed === 1) console.log(`    进度: 本任务已处理 ${processed} 帖（失败帖 ${pageErr}）` + (NO_CMT ? "" : ` / 评论 ${commentsTotal} 条（本页 ${pageComments} 条）`));
    }
    saveMeta({ done_pages: page, stop_reason: "", posts_processed: processed, comments_total: commentsTotal, dropped });
    const pageKept = fresh.length - pageDrop;
    console.log(`  [页 ${page}] 完成: 保留 ${pageKept} / 丢弃 ${pageDrop} 帖${COMMENT_MODE === "off" ? "" : `, 评论 ${pageComments} 条`}\n`);
    await sleep(jitter(2500, 4000)); // 页间间隔
  }

  if (ndjsonStream.fd) fs.closeSync(ndjsonStream.fd);
  const state = { posts_processed: processed, comments_total: commentsTotal, dropped, stop_reason: stopReason };
  saveMeta({ ...state });
  console.log(`\n抓取阶段结束: ${stopReason || `已完成 ${PAGES} 页`}`);
  console.log(`已处理帖子 ${seen.size} 条(保留 ${processed} / 丢弃 ${dropped}), 评论 ${commentsTotal} 条 → ${NDJSON}`);
  if (stopReason && !/正常结束/.test(stopReason)) {
    console.log("提示: 中断原因多为风控，稍后(建议 30 分钟以上)用相同 --out 目录重跑即可断点续爬。");
  }
  return { seen, commentsTotal };
}

// ---------------- 聚合输出 ----------------
function build() {
  if (!fs.existsSync(NDJSON)) { console.error(`没有数据文件: ${NDJSON}（先运行抓取）`); process.exit(1); }
  const posts = [];
  const lines = fs.readFileSync(NDJSON, "utf8").split("\n");
  for (const ln of lines) {
    if (!ln.trim()) continue;
    try { posts.push(JSON.parse(ln)); } catch (e) {}
  }
  let commentsTotal = 0, commentsVisible = 0, detailFail = 0, commentFail = 0;
  for (const p of posts) {
    if (!p.detail) { detailFail++; continue; }
    commentsTotal += (p.comments?.list || []).length;
    commentsVisible += (p.comments?.visible || 0);
    if (p.comments?.error || p.comments?.partial) commentFail++;
  }
  const topic = {
    query: QUERY, timescope: TIMESCOPE || null, comment_mode: COMMENT_MODE,
    search_url: SEARCH_NO_PAGE + "&page=1",
    scraped_at: new Date().toISOString().slice(0, 19).replace("T", " "),
    structure: COMMENT_MODE === "off" ? "topic -> post(page,rank)" : "topic -> post(page,rank) -> comment",
  };
  const summary = {
    posts: posts.length, posts_detail_ok: posts.length - detailFail, posts_detail_fail: detailFail,
    comments_annotated_unknown: null,
    comments_fetched: commentsTotal, comments_visible: commentsVisible, comments_partial_fail: commentFail,
  };
  const out = { topic, summary, posts };
  fs.writeFileSync(path.join(OUT_DIR, "topic.json"), JSON.stringify(out, null, 2), "utf8");
  // posts.csv
  const pHeaders = ["page", "rank_in_page", "mid", "mblogid", "url", "博主昵称", "博主uid", "认证", "发布时间", "显示时间", "地区", "来源", "转发", "评论", "点赞", "话题", "图片数", "视频标题", "是否长文", "正文"];
  const pRows = [];
  for (const p of posts) {
    const d = p.detail;
    if (!d) continue;
    pRows.push([p.page, p.card?.rank_in_page ?? "", d.mid, d.mblogid, d.url, d.user?.screen_name, d.user?.uid, d.user?.verified ? ("是(" + (d.user.verified_type ?? "") + ")") : "否", d.created_at, d.created_at_display, d.region_name, d.source, d.reposts_count, d.comments_count, d.attitudes_count, (d.topics || []).join(";"), d.pic_num, d.video?.title || "", d.isLongText ? "是" : "否", d.text]);
  }
  writeCsv(path.join(OUT_DIR, "posts.csv"), pHeaders, pRows);
  // comments.csv
  const cHeaders = ["page", "帖mid", "博主昵称", "楼层", "评论id", "rootid", "评论链接", "评论用户", "评论uid", "认证", "粉丝数", "会员等级", "地区", "性别", "评论时间", "来源", "点赞", "楼中楼数", "正文"];
  const cRows = [];
  for (const p of posts) {
    const d = p.detail;
    if (!d) continue;
    for (const c of p.comments?.list || []) {
      cRows.push([p.page, d.mid, d.user?.screen_name, c.floor_number, c.comment_id, c.rootid, c.url, c.user?.screen_name, c.user?.uid, c.user?.verified ? ("是(" + (c.user.verified_type ?? "") + ")") : "否", c.user?.followers_count, c.user?.mbrank, c.user?.location, c.user?.gender, c.created_at, c.source, c.like_counts, c.reply_total, c.text].map(esc));
    }
  }
  writeCsv(path.join(OUT_DIR, "comments.csv"), cHeaders, cRows);
  console.log(`聚合完成 → ${OUT_DIR}`);
  console.log(`  帖子 ${summary.posts} 条(详情失败 ${summary.posts_detail_fail}) | 评论 ${summary.comments_fetched} 条(可见 ${summary.comments_visible})`);
  console.log(`  topic.json / posts.csv / comments.csv`);
}

// ---------------- 入口 ----------------
(async () => {
  if (BUILD_ONLY) { build(); return; }
  const r = await crawl();
  console.log("\n开始聚合输出 ...");
  build();
  console.log("全部完成。");
})().catch((e) => { console.error("运行失败:", e); process.exit(1); });
