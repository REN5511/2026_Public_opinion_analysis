#!/usr/bin/env node
/**
 * 密度探测: 对 [BOTTOM, TOP] 逐日请求 s.weibo 搜索 page=1, 解析
 *   <span class="page-info">共X页/Y条</span>
 * 得到每天的(总页数, 总条数)。Y>=500 时微博显示封顶 50页/500条, 标记 overflow。
 * 输出 JSON 到 out/density_probe_<top>.json, 供按密度比例抽样使用。
 */
const fs = require("fs");
const path = require("path");
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const COOKIE = fs.readFileSync(path.join(__dirname, "cookies.txt"), "utf8").trim();
const Q = encodeURIComponent("世界杯佛得角");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      const eq = k.indexOf("=");
      if (eq >= 0) a[k.slice(0, eq)] = k.slice(eq + 1);
      else { a[k] = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[i + 1] : true; i += a[k] === true ? 0 : 1; }
    }
  }
  return a;
}
const ARG = parseArgs(process.argv);
const BOTTOM = ARG.bottom || "2026-05-28";
const TOP = ARG.top || "2026-07-18";
const GAP = parseFloat(ARG.gap || "1.1"); // 请求间隔秒

function dateRange(fromStr, toStr) {
  const out = [];
  let cur = Date.UTC(+fromStr.slice(0, 4), +fromStr.slice(5, 7) - 1, +fromStr.slice(8, 10));
  const end = Date.UTC(+toStr.slice(0, 4), +toStr.slice(5, 7) - 1, +toStr.slice(8, 10));
  while (cur <= end) { const x = new Date(cur); out.push(`${x.getUTCFullYear()}-${String(x.getUTCMonth() + 1).padStart(2, "0")}-${String(x.getUTCDate()).padStart(2, "0")}`); cur += 86400000; }
  return out;
}
async function probeDay(day) {
  const url = `https://s.weibo.com/weibo?q=${Q}&typeall=1&suball=1&timescope=${encodeURIComponent(`custom:${day}:${day}`)}&Refer=g&page=1`;
  try {
    const res = await fetch(url, { headers: { "User-Agent": UA, Referer: "https://s.weibo.com/", "Accept-Language": "zh-CN,zh;q=0.9", Cookie: COOKIE } });
    const h = await res.text();
    const m = /<span class="page-info">共(\d+)页\/(\d+)条<\/span>/.exec(h);
    if (m) {
      const pages = +m[1], total = +m[2];
      return { day, pages, total, overflow: total >= 500, cards: (h.match(/action-type="feed_list_item"/g) || []).length };
    }
    // 无卡片且无 page-info
    const cards = (h.match(/action-type="feed_list_item"/g) || []).length;
    return { day, pages: 0, total: cards > 0 ? cards : 0, overflow: false, cards, noinfo: !cards };
  } catch (e) {
    return { day, pages: -1, total: -1, overflow: false, cards: 0, error: String(e.message || e) };
  }
}
(async () => {
  const days = dateRange(BOTTOM, TOP);
  const out = [];
  console.log(`密度探测: ${days.length} 天 (${BOTTOM} ~ ${TOP})`);
  for (let i = 0; i < days.length; i++) {
    const r = await probeDay(days[i]);
    out.push(r);
    console.log(`${r.day}: 共${r.pages}页/${r.total}条${r.overflow ? " [溢出≥500]" : ""}${r.cards ? ` 页1卡片${r.cards}` : ""}${r.error ? ` 错误:${r.error}` : ""}`);
    await sleep(GAP * 1000);
  }
  fs.mkdirSync(path.join(__dirname, "out"), { recursive: true });
  const f = path.join(__dirname, "out", `density_probe_${BOTTOM}_${TOP}.json`);
  fs.writeFileSync(f, JSON.stringify(out, null, 2), "utf8");
  const sum = out.reduce((s, r) => s + (r.total > 0 ? r.total : 0), 0);
  const over = out.filter((r) => r.overflow).length;
  console.log(`\n完成 → ${f}`);
  console.log(`  有内容天数 ${out.filter((r) => r.total > 0).length}/${days.length} | 溢出(≥500条) ${over} 天 | 可知总量合计 ${sum}(不含溢出) | 估计总量 ≥ ${sum + over * 500}`);
})();
