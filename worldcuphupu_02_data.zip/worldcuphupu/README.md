# 佛得角事件统一格式副本

data/ 是已整理、用于上传的统一数据目录。唯一当前主结果为：

data/processed/hupu_evt_2026_fifa_world_cup_cape_verde.json

冗余archive备份已按要求删除。原工程仍在同级“佛得角事件”目录中，当前副本仅用于统一格式数据交付。

原始“佛得角事件”目录完全未修改。昵称等原信息按用户要求保留，未脱敏。API相关记录为null。

详细目录、路径基准及限制见data/README.md。原工程爬虫仍依赖历史布局，不应直接用于覆盖统一data目录。


## 分包上传与解压

本交付包为满足GitHub网页单文件25 MB限制，分为两个独立ZIP，两个包都需要下载：

| 压缩包 | 内容 |
| --- | --- |
| worldcuphupu_01_raw.zip | data/raw 原始证据 |
| worldcuphupu_02_data.zip | data/interim、data/processed、README及清理说明 |

将两个ZIP解压到同一个目标文件夹，允许合并同名目录。两个包均带有worldcuphupu/顶层目录，合并后应得到：

```text
worldcuphupu/
├─ data/
│  ├─ raw/
│  ├─ interim/
│  ├─ processed/
│  └─ README.md
├─ README.md
└─ cleanup_report.json
```

不要分别解压到以ZIP文件名命名的两个隔离目录。若软件自动创建了这样的目录，请将其中两个worldcuphupu文件夹合并。两个包不是需要专用工具拼接的分卷压缩包，可以独立解压。

主结果仍为data/processed/hupu_evt_2026_fifa_world_cup_cape_verde.json。仅做分析可以先读取第二包；需要按raw_path回查证据时，必须下载并合并第一包。分包不改变JSON字段、样本数量或引用路径；API记录为null，昵称等原信息仍保留。
