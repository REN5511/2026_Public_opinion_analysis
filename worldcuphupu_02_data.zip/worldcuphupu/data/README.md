# 佛得角事件 · 虎扑数据说明

本目录保存“2026年FIFA世界杯佛得角队相关舆情”项目的虎扑采集数据，供跨平台汇总、内容分析及证据核验使用。数据来自公开网页，原始响应主要为 HTML。

分析时请优先读取以下最终文件：

[processed/hupu_evt_2026_fifa_world_cup_cape_verde.json](processed/hupu_evt_2026_fifa_world_cup_cape_verde.json)

## 1. 本批次概况

| 项目 | 内容 |
| --- | --- |
| 来源平台 | 虎扑（`source_id: hupu`） |
| 统一事件编号 | `evt_2026_fifa_world_cup_cape_verde` |
| 帖子数量 | 76 条 |
| 评论数量 | 13,166 条 |
| 文档总数 | 13,242 条 |
| 候选链接数量 | 85 个：76 个合格、7 个筛除、2 个无法访问 |
| 组织方式 | 帖子为主体，评论为辅助；两类记录独立保存并通过 ID 关联 |
| 编码 | 最终 JSON 使用 UTF-8 |
| 用户信息 | 保留原数据中的公开昵称等信息，未脱敏 |

以上数量对应当前交付批次。若之后重新采集或更新数据，应以最新主结果中的 `stats` 为准。

## 2. 日期与筛选规则

采集条件为北京时间 **2026年5月28日00:00至2026年7月27日00:00之前**，即包含5月28日至7月26日。

统一字段采用 UTC 表示同一时间范围：

```json
{
  "start": "2026-05-27T16:00:00Z",
  "end_exclusive": "2026-07-26T16:00:00Z"
}
```

时间窗口左闭右开。格式转换没有改变原来的实际时刻或筛选边界。该窗口与组内 YouTube 说明中采用的 UTC 日期窗口相差8小时，跨平台分析时应明确统一口径。

帖子按标题与正文筛选：至少命中一个主体词、至少命中一个事件词，且不含排除词；发布时间须在上述范围内。主体词为“佛得角”“沃齐尼亚”，完整三组词表保存在主结果顶层的 `extra.hupu_original_fields.filter_config`。

评论继承所属合格帖子的事件相关性，并单独核验发布时间；不要求每条评论再次命中帖子的关键词。

## 3. 目录结构

```text
data/
├─ raw/
│  └─ hupu/evt_2026_fifa_world_cup_cape_verde/
│     ├─ search/                  搜索发现证据
│     ├─ posts/<post_id>/         帖子首页 HTML 及响应头
│     ├─ comments/<post_id>/      后续评论分页 HTML 及响应头
│     └─ supporting/             历史探测、请求记录及补充证据
├─ interim/
│  └─ hupu/
│     ├─ quota_ledger.json        内容为 null，无官方 API 配额账本
│     └─ evt_2026_fifa_world_cup_cape_verde/
│        ├─ state.json           整理时的状态、数量与失败记录
│        ├─ search_index.json    帖子与搜索证据的对应关系
│        ├─ documents/           每条帖子或评论一个 JSON 文件
│        ├─ legacy_intermediate/ 历史中间数据
│        ├─ raw_manifest.json    原始文件清单与 SHA-256
│        ├─ path_mapping.json    整理前后的路径对应表
│        └─ packaging_verification.json
│                                整理时的核验报告
├─ processed/
│  └─ hupu_evt_2026_fifa_world_cup_cape_verde.json
└─ README.md
```

`raw` 用于证据回溯，`interim` 用于核验和保存中间信息，`processed` 用于正式分析。这三层可能包含同一对象的不同表示，不能重复计为样本。

帖子首页可能同时包含评论。因此，部分评论的 `raw_path` 指向 `posts` 中的首页文件，这是正常情况，不代表关联错误。

## 4. 最终 JSON 结构

| 顶层字段 | 含义 |
| --- | --- |
| `schema_version` | 统一格式版本 |
| `event_id`、`event_name` | 统一事件编号与名称 |
| `collected_at` | 原结果记录的采集时间，转换为 UTC |
| `collection_window` | 时间范围，结束边界不包含在内 |
| `queries` | 本批次为 `null`，未补造完整查询对象 |
| `documents` | 帖子与评论的独立文档数组 |
| `failed_items` | 无法读取对象及失败原因 |
| `stats` | 文档数量、失败与筛除数量等统计 |
| `extra` | 原顶层信息及整理说明 |

每条文档通过 `doc_type` 区分：`post` 表示帖子，`comment` 表示评论。

| 文档字段 | 含义与使用说明 |
| --- | --- |
| `doc_id` | 数据集内唯一编号 |
| `source_id`、`source_name` | `hupu`、虎扑 |
| `platform_object_id` | 平台原始帖子或评论编号；评论编号应结合所属帖子使用 |
| `canonical_url` | 帖子原文链接；未验证的评论直达链接为 `null` |
| `published_at` | UTC 发布时间 |
| `content_text` | 帖子正文或评论正文 |
| `language` | 未取得可靠的逐条语言标注，填 `null` |
| `raw_path` | 相对于本 `data` 目录的原始响应路径 |
| `content_hash` | 规范化正文的 SHA-256，不是原始 HTML 文件的哈希 |
| `query_ids` | 本批次为 `null`；已有搜索证据另存于索引及扩展字段 |
| `matched_keywords` | 帖子命中的主体词与事件词；评论为 `null` |
| `metrics` | 可统一解释的互动指标，见下表 |
| `duplicate_of` | 保留原帖子的重复关联；未关联时为 `null` |
| `parent_doc_id` | 帖子为 `null`；评论指向原父评论，或在无父评论记录时指向所属帖子 |
| `root_doc_id` | 所属根帖子的文档编号 |
| `thread_id` | `hupu:<post_id>`，用于聚合同帖讨论 |
| `author_id_hash` | 未生成作者 ID 哈希，填 `null` |
| `extra` | 虎扑原字段和必要的平台差异信息 |

`metrics` 的当前口径如下：

| 字段 | 含义 |
| --- | --- |
| `view_count` | 帖子原阅读量；评论为 `null` |
| `like_count` | 未可靠取得，保留 `null` |
| `comment_count` | 帖子的原平台评论计数，不等于实际保存评论数 |
| `reply_count` | 单条评论的回复数量；本批次未取得，填 `null` |

`null` 表示未取得或不适用，不能替换成0。虎扑原推荐数、点亮数及其他计数保留在扩展字段中，不与其他平台的点赞数直接混用。

## 5. 原字段保留方式

对齐时没有删除原数据字段：

- 每条文档的 `extra.hupu_original_fields` 保存其原字段和值。
- 帖子的原 `comments` 数组已展开为独立文档，不重复嵌套保存。
- 顶层 `extra.hupu_original_fields` 保存原事件信息、筛选配置、失败明细、筛除明细和采集范围。
- 帖子标题可读取 `extra.title`；原作者、栏目等可读取 `extra.hupu_original_fields.author`、`extra.hupu_original_fields.section`。

统一字段适合跨平台分析，扩展字段适合虎扑特有分析和审计。两者有意保留部分重复信息，统计时只计算 `documents` 中的记录。

## 6. 路径与证据回溯

标准 `raw_path` 相对于本 `data` 目录，例如：

```text
raw/hupu/evt_2026_fifa_world_cup_cape_verde/posts/640940624/640940624.html
```

扩展字段中的原路径也已更新，但仍相对于副本根目录，带有 `data/` 前缀。只拿到本 `data` 目录时，解析这些路径需先移除前导 `data/`。

`path_mapping.json` 保存新旧路径的对应关系。原始文件内容保持字节不变；历史响应内部若仍含旧路径，可通过对应表定位。`supporting` 中包含先前平台测试等辅助材料，不应将其全部视为当前事件的合格样本。

证据回溯顺序：

```text
事件 → Document → raw_path → 原始页面中的帖子或评论对象
```

## 7. 覆盖范围与使用限制

1. 本批次来自已发现的候选链接，不保证覆盖虎扑全站所有相关帖子。
2. 已处理合格帖子的公开普通评论分页，但存在日期过滤和平台返回限制，不能声称取得所有评论。采样方式不同于 YouTube 的相关性排序及页数上限。
3. 1,114条评论的父引用在数据集中没有对应节点；所有根帖子均存在。构建回复关系图时，应将这些父节点视为缺失，不应自动改挂或编造。
4. API用量与配额账本为 `null`，表示本批次没有官方API用量账本，不表示没有发生网络请求。
5. 昵称等原信息按要求保留。此数据未采用 YouTube 组员的作者脱敏方式。
6. 本格式依据组内说明对齐，尚未通过对方正式 JSON Schema 验证。接收程序应支持 `post` 类型、`extra` 扩展和可空字段。

## 8. 核验与交付

整理时已验证：原工程文件未修改、记录数量一致、逐条中间 JSON 与主结果一致、原始文件哈希一致，以及经逆向路径映射后能够还原全部原JSON字段。

核验报告位于：

[packaging_verification.json](interim/hupu/evt_2026_fifa_world_cup_cape_verde/packaging_verification.json)

`state.json` 是整理状态快照，不是可直接用于续爬的运行断点。它和核验报告中有关 `archive` 的字段记录的是整理当时状态；该冗余备份后来已删除，不属于本交付目录，不影响主结果和本地证据的使用。

交付时请整体保留本 `data` 目录。分析程序只读取 `processed` 中的主结果；需要复查时再读取 `raw` 和 `interim`。本目录为数据交付包，不包含或依赖爬虫脚本。


## 本次上传包清理

删除未被主结果引用的历史平台测试文件及误放脚本；仅精简非raw目录JSON的空白，字段和值保持不变。原始网页字节保持不变。原整理核验报告为历史记录；本次清理结果另见上传包根目录cleanup_report.json。


## 分包上传与解压

本交付包为满足GitHub网页单文件25 MB限制，分为两个独立ZIP，两个包都需要下载：

| 压缩包 | 内容 |
| --- | --- |
| worldcuphupu_01_raw.zip | data/raw 原始证据 |
| worldcuphupu_02_data.zip | data/interim、data/processed、README及清理说明 |

将两个ZIP解压到同一个目标文件夹，允许合并同名目录。两个包均带有worldcuphupu/顶层目录，合并后应得到：

```text
worldcuphupu/
├─ data/
│  ├─ raw/
│  ├─ interim/
│  ├─ processed/
│  └─ README.md
├─ README.md
└─ cleanup_report.json
```

不要分别解压到以ZIP文件名命名的两个隔离目录。若软件自动创建了这样的目录，请将其中两个worldcuphupu文件夹合并。两个包不是需要专用工具拼接的分卷压缩包，可以独立解压。

主结果仍为data/processed/hupu_evt_2026_fifa_world_cup_cape_verde.json。仅做分析可以先读取第二包；需要按raw_path回查证据时，必须下载并合并第一包。分包不改变JSON字段、样本数量或引用路径；API记录为null，昵称等原信息仍保留。
